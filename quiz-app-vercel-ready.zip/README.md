# Capital Budgeting Quiz

Ứng dụng ôn thi trắc nghiệm cho môn **Hoạch định Ngân sách Vốn Đầu tư**. App dùng Next.js App Router, TypeScript, Tailwind CSS, dữ liệu local-first và question bank trích xuất từ `file trắc nghiệm hđ.docx`.

## Tính năng

- Dashboard: tổng số câu, số câu đã làm, tỷ lệ đúng, câu sai cần ôn, streak và tiến độ theo chương.
- Practice: lọc theo chương, nhóm câu, số lượng, trộn câu hỏi, trộn đáp án, chỉ câu chưa làm hoặc câu sai.
- Exam: chọn số câu/thời gian, timer, không hiện đáp án trước khi nộp, sau khi nộp có điểm số và review.
- Review: lọc câu sai theo chương và số lần sai, luyện lại toàn bộ câu sai.
- Question bank: search, filter theo chương/nhóm, bật/tắt đáp án, xem chi tiết từng câu.
- Progress: accuracy theo chương, top chương yếu, câu hay sai, lịch sử thi thử.

## Cài đặt

```bash
npm install
```

Trên PowerShell nếu `npm` bị chặn bởi execution policy, dùng:

```powershell
npm.cmd install
```

## Chạy dev

```bash
npm run dev
```

Mở `http://localhost:3000`.

## Kiểm tra chất lượng

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

## Cập nhật ngân hàng câu hỏi

Question bank nằm ở `src/data/questions.ts` và được sinh từ DOCX bằng script:

```bash
python scripts/extract_docx_questions.py "C:\path\to\file trắc nghiệm hđ.docx" --out src/data/questions.ts --report src/data/questions.report.json
```

Script yêu cầu Python có `python-docx`:

```bash
pip install python-docx
```

Sau khi sinh lại dữ liệu, chạy:

```bash
npm run test
npm run typecheck
```

## Cấu trúc chính

```txt
src/
  app/
    page.tsx
    practice/
    exam/
    review/
    questions/
    progress/
  components/
  data/questions.ts
  lib/
  types/quiz.ts
tests/
scripts/extract_docx_questions.py
```
