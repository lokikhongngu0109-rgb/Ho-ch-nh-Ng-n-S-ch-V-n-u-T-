from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from docx import Document


CHOICE_RE = re.compile(r"^([A-E])\)\s*(.+)$")
QUESTION_RE = re.compile(r"^Câu\s+(B?\d+)\.\s*(.+)$")
MAIN_CHAPTER_RE = re.compile(r"^CHƯƠNG\s+(\d+)\s+[—-]\s+(.+)$")
SUPPLEMENT_RE = re.compile(r"^BỔ SUNG\s+(\d+)\s+[—-]\s+(.+)$")
ANSWER_MAIN_RE = re.compile(r"CHƯƠNG\s+(\d+):\s*(.+)$")
ANSWER_PAIR_RE = re.compile(r"\b(B?\d+)-([A-E])\b")
TRAP_ID_RE = re.compile(r"\b(C\d+\.\d+|B\d+)\b")


def normalize_text(value: str) -> str:
    return re.sub(r"\s+", " ", value.strip())


def source_id_for(question_id: str, chapter: str) -> str:
    if question_id.startswith("B"):
        return question_id
    return f"C{chapter}.{int(question_id)}"


def app_id_for(question_id: str, chapter: str) -> str:
    if question_id.startswith("B"):
        return f"B{int(question_id[1:]):02d}"
    return f"C{chapter}-{int(question_id):02d}"


def parse_answers(lines: list[str]) -> dict[str, str]:
    answers: dict[str, str] = {}
    for line in lines:
        main_match = ANSWER_MAIN_RE.match(line)
        if main_match:
            chapter, rest = main_match.groups()
            for number, answer in ANSWER_PAIR_RE.findall(rest):
                answers[app_id_for(number, chapter)] = answer
            continue

        for number, answer in ANSWER_PAIR_RE.findall(line):
            if number.startswith("B"):
                answers[app_id_for(number, "")] = answer
    return answers


def parse_trap_notes(lines: list[str]) -> dict[str, list[str]]:
    notes: dict[str, list[str]] = {}
    for line in lines:
        if not line.startswith("-"):
            continue
        note = normalize_text(line[1:])
        for source_id in TRAP_ID_RE.findall(note):
            if source_id.startswith("C"):
                chapter, number = source_id[1:].split(".")
                key = app_id_for(number, chapter)
            else:
                key = app_id_for(source_id, "")
            notes.setdefault(key, []).append(note)
    return notes


def parse_questions(lines: list[str], answers: dict[str, str], trap_notes: dict[str, list[str]]) -> list[dict[str, Any]]:
    questions: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None
    current_chapter = ""
    current_chapter_title = ""
    current_section = ""
    current_topic: str | None = None

    def finish_current() -> None:
        nonlocal current
        if not current:
            return
        current["question"] = normalize_text(" ".join(current.pop("_question_lines")))
        current["correctAnswer"] = answers.get(current["id"])
        if current["id"] in trap_notes:
            current["trapNote"] = " ".join(trap_notes[current["id"]])
        if current["section"] == "must_know":
            current["difficulty"] = "basic"
        elif current["section"] == "easy_to_miss":
            current["difficulty"] = "medium"
        elif any(token in current["question"].lower() for token in ["tính toán", "capm", "wacc", "apv", "beta"]):
            current["difficulty"] = "hard"
        else:
            current["difficulty"] = "medium"
        questions.append(current)
        current = None

    for line in lines:
        if line.startswith("ĐÁP ÁN ĐẦY ĐỦ"):
            finish_current()
            break
        if not line or set(line) <= {"=", "-"}:
            continue

        chapter_match = MAIN_CHAPTER_RE.match(line)
        if chapter_match:
            finish_current()
            current_chapter, current_chapter_title = chapter_match.groups()
            current_chapter_title = normalize_text(current_chapter_title.title())
            current_section = ""
            current_topic = None
            continue

        supplement_match = SUPPLEMENT_RE.match(line)
        if supplement_match:
            finish_current()
            supplement_number, title = supplement_match.groups()
            current_chapter = f"SUP{supplement_number}"
            current_chapter_title = f"Bổ sung {supplement_number}: {normalize_text(title)}"
            current_section = "supplement"
            current_topic = normalize_text(title)
            continue

        if "BẮT BUỘC PHẢI BIẾT" in line:
            finish_current()
            current_section = "must_know"
            current_topic = None
            continue

        if "DỄ BỎ SÓT" in line:
            finish_current()
            current_section = "easy_to_miss"
            current_topic = None
            continue

        question_match = QUESTION_RE.match(line)
        if question_match:
            finish_current()
            source_number, question_text = question_match.groups()
            if not current_chapter or not current_section:
                raise ValueError(f"Question without chapter/section: {line}")
            app_id = app_id_for(source_number, current_chapter.replace("SUP", ""))
            current = {
                "id": app_id,
                "sourceId": source_id_for(source_number, current_chapter.replace("SUP", "")),
                "chapter": f"C{current_chapter}" if current_chapter.isdigit() else current_chapter,
                "chapterTitle": current_chapter_title,
                "section": current_section,
                "topic": current_topic,
                "_question_lines": [question_text],
                "choices": [],
            }
            continue

        choice_match = CHOICE_RE.match(line)
        if choice_match and current is not None:
            key, text = choice_match.groups()
            current["choices"].append({"key": key, "text": normalize_text(text)})
            continue

        if current is not None:
            if current["choices"]:
                current["choices"][-1]["text"] = normalize_text(f"{current['choices'][-1]['text']} {line}")
            else:
                current["_question_lines"].append(line)

    return questions


def validate_questions(questions: list[dict[str, Any]]) -> None:
    ids = [question["id"] for question in questions]
    duplicate_ids = sorted({item for item in ids if ids.count(item) > 1})
    if duplicate_ids:
        raise ValueError(f"Duplicate ids: {duplicate_ids}")

    errors: list[str] = []
    for question in questions:
        if len(question["choices"]) != 5:
            errors.append(f"{question['id']} has {len(question['choices'])} choices")
        if question.get("correctAnswer") not in {"A", "B", "C", "D", "E"}:
            errors.append(f"{question['id']} missing valid answer")
        if question.get("correctAnswer") not in {choice["key"] for choice in question["choices"]}:
            errors.append(f"{question['id']} answer not in choices")
    if errors:
        raise ValueError("\n".join(errors))


def render_ts(questions: list[dict[str, Any]]) -> str:
    serialized = json.dumps(questions, ensure_ascii=False, indent=2)
    return (
        'import type { Question } from "../types/quiz";\n\n'
        "export const questions = "
        + serialized
        + " satisfies Question[];\n\n"
        "export const QUESTION_BANK_SOURCE = {\n"
        '  title: "Hoạch định Ngân sách Vốn Đầu tư",\n'
        '  sourceFile: "file trắc nghiệm hđ.docx",\n'
        f"  totalQuestions: {len(questions)},\n"
        '  answerSource: "ĐÁP ÁN ĐẦY ĐỦ",\n'
        "} as const;\n"
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Extract quiz questions from the source DOCX.")
    parser.add_argument("docx", type=Path)
    parser.add_argument("--out", type=Path, default=Path("src/data/questions.ts"))
    parser.add_argument("--report", type=Path, default=Path("src/data/questions.report.json"))
    args = parser.parse_args()

    document = Document(args.docx)
    lines = [normalize_text(paragraph.text) for paragraph in document.paragraphs if normalize_text(paragraph.text)]
    answer_start = next(index for index, line in enumerate(lines) if line.startswith("ĐÁP ÁN ĐẦY ĐỦ"))
    traps_start = next(index for index, line in enumerate(lines) if line.startswith("GHI CHÚ NHANH"))
    answers = parse_answers(lines[answer_start:traps_start])
    trap_notes = parse_trap_notes(lines[traps_start:])
    questions = parse_questions(lines, answers, trap_notes)
    validate_questions(questions)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(render_ts(questions), encoding="utf-8")
    args.report.write_text(
        json.dumps(
            {
                "totalQuestions": len(questions),
                "chapters": {chapter: sum(1 for q in questions if q["chapter"] == chapter) for chapter in sorted({q["chapter"] for q in questions})},
                "sections": {section: sum(1 for q in questions if q["section"] == section) for section in sorted({q["section"] for q in questions})},
                "answers": len(answers),
                "trapNotes": sum(len(value) for value in trap_notes.values()),
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    print(f"Extracted {len(questions)} questions to {args.out}")


if __name__ == "__main__":
    main()
