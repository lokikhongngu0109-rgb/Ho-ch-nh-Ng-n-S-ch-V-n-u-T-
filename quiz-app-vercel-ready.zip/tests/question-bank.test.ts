import { describe, expect, it } from "vitest";
import { questions } from "../src/data/questions";
import { filterQuestions } from "../src/lib/filters";
import { shouldRevealAnswer } from "../src/lib/quiz";
import { scoreAnswers } from "../src/lib/scoring";
import { validateQuestionBank } from "../src/lib/validation";

describe("question bank", () => {
  it("contains the extracted DOCX questions and valid answers", () => {
    const result = validateQuestionBank(questions);

    expect(questions).toHaveLength(112);
    expect(result.errors).toEqual([]);
    expect(result.valid).toBe(true);
  });

  it("keeps every question to exactly five choices", () => {
    expect(questions.every((question) => question.choices.length === 5)).toBe(true);
  });

  it("has no missing answer keys", () => {
    expect(questions.every((question) => ["A", "B", "C", "D", "E"].includes(question.correctAnswer))).toBe(true);
  });
});

describe("scoring", () => {
  it("scores correct, incorrect, and unanswered answers", () => {
    const sample = questions.slice(0, 3);
    const result = scoreAnswers(sample, {
      [sample[0].id]: sample[0].correctAnswer,
      [sample[1].id]: "A",
    });

    expect(result.total).toBe(3);
    expect(result.correct).toBe(sample[1].correctAnswer === "A" ? 2 : 1);
    expect(result.unanswered).toBe(1);
  });
});

describe("filters", () => {
  it("filters by chapter and section", () => {
    const filtered = filterQuestions(questions, { chapter: "C4", section: "must_know" });

    expect(filtered).toHaveLength(7);
    expect(filtered.every((question) => question.chapter === "C4")).toBe(true);
    expect(filtered.every((question) => question.section === "must_know")).toBe(true);
  });
});

describe("exam reveal rules", () => {
  it("does not reveal exam answers before submission", () => {
    expect(shouldRevealAnswer("exam", false)).toBe(false);
    expect(shouldRevealAnswer("exam", true)).toBe(true);
    expect(shouldRevealAnswer("practice", false)).toBe(true);
  });
});
