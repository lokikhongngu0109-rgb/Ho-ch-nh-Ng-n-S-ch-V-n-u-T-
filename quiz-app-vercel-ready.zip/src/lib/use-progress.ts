"use client";

import { useCallback, useSyncExternalStore } from "react";
import type { ChoiceKey, ExamSessionSummary, ProgressState, Question } from "@/types/quiz";
import {
  addExamSession,
  clearWrongQuestion,
  createEmptyProgress,
  loadProgress,
  recordQuestionAnswer,
  saveProgress,
  STORAGE_KEY,
  toggleMarked,
} from "@/lib/storage";

const PROGRESS_EVENT = "capital-budgeting-progress-updated";
const SERVER_PROGRESS = createEmptyProgress();
let cachedRaw: string | null | undefined;
let cachedProgress = SERVER_PROGRESS;

export function useProgress() {
  const progress = useSyncExternalStore(subscribe, getProgressSnapshot, getServerProgressSnapshot);

  const commit = useCallback((updater: (current: ProgressState) => ProgressState) => {
    const next = updater(loadProgress());
    saveProgress(next);
    cacheProgress(next);
    notify();
  }, []);

  const recordAnswer = useCallback(
    (question: Question, selectedAnswer: ChoiceKey | undefined, mode: "practice" | "exam") => {
      commit((current) => recordQuestionAnswer(current, question, selectedAnswer, mode));
    },
    [commit],
  );

  const markQuestion = useCallback(
    (questionId: string) => {
      commit((current) => toggleMarked(current, questionId));
    },
    [commit],
  );

  const clearWrong = useCallback(
    (questionId: string) => {
      commit((current) => clearWrongQuestion(current, questionId));
    },
    [commit],
  );

  const storeExam = useCallback(
    (exam: ExamSessionSummary) => {
      commit((current) => addExamSession(current, exam));
    },
    [commit],
  );

  const reset = useCallback(() => {
    saveProgress(createEmptyProgress());
    notify();
  }, []);

  return {
    ready: true,
    progress,
    recordAnswer,
    markQuestion,
    clearWrong,
    storeExam,
    reset,
  };
}

function subscribe(callback: () => void) {
  if (typeof window === "undefined") {
    return () => undefined;
  }
  window.addEventListener(PROGRESS_EVENT, callback);
  window.addEventListener("storage", callback);
  return () => {
    window.removeEventListener(PROGRESS_EVENT, callback);
    window.removeEventListener("storage", callback);
  };
}

function notify() {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new Event(PROGRESS_EVENT));
  }
}

function getProgressSnapshot() {
  if (typeof window === "undefined") {
    return SERVER_PROGRESS;
  }

  const raw = window.localStorage.getItem(STORAGE_KEY);
  if (raw === cachedRaw) {
    return cachedProgress;
  }

  cachedRaw = raw;
  cachedProgress = loadProgress();
  return cachedProgress;
}

function getServerProgressSnapshot() {
  return SERVER_PROGRESS;
}

function cacheProgress(progress: ProgressState) {
  cachedProgress = progress;
  cachedRaw =
    typeof window === "undefined" ? JSON.stringify(progress) : window.localStorage.getItem(STORAGE_KEY);
}
