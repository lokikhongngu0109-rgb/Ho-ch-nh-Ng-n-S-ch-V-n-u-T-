import type {
  ChoiceKey,
  ExamSessionSummary,
  ProgressState,
  Question,
  QuestionProgress,
} from "@/types/quiz";

export const STORAGE_KEY = "capital-budgeting-quiz-progress-v1";

export function createEmptyProgress(): ProgressState {
  return {
    version: 1,
    questions: {},
    exams: [],
    streak: { count: 0 },
  };
}

export function loadProgress(): ProgressState {
  if (typeof window === "undefined") {
    return createEmptyProgress();
  }

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return createEmptyProgress();
    }
    return migrateProgress(JSON.parse(raw));
  } catch {
    return createEmptyProgress();
  }
}

export function saveProgress(progress: ProgressState) {
  if (typeof window === "undefined") {
    return;
  }
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
}

export function recordQuestionAnswer(
  progress: ProgressState,
  question: Question,
  selectedAnswer: ChoiceKey | undefined,
  mode: "practice" | "exam",
): ProgressState {
  const now = new Date().toISOString();
  const existing = progress.questions[question.id] ?? createEmptyQuestionProgress();
  const isCorrect = selectedAnswer === question.correctAnswer;
  const correctStreak = isCorrect ? existing.correctStreak + 1 : 0;

  const nextRecord: QuestionProgress = {
    ...existing,
    attempts: existing.attempts + 1,
    correct: existing.correct + (isCorrect ? 1 : 0),
    wrong: existing.wrong + (isCorrect ? 0 : 1),
    correctStreak,
    needsReview: isCorrect ? correctStreak < 2 && existing.needsReview : true,
    lastAnsweredAt: now,
    lastSelectedAnswer: selectedAnswer,
    history: [
      {
        selectedAnswer,
        correctAnswer: question.correctAnswer,
        isCorrect,
        mode,
        answeredAt: now,
      },
      ...existing.history,
    ].slice(0, 20),
  };

  return {
    ...progress,
    questions: {
      ...progress.questions,
      [question.id]: nextRecord,
    },
    streak: updateStreak(progress.streak),
  };
}

export function toggleMarked(progress: ProgressState, questionId: string) {
  const existing = progress.questions[questionId] ?? createEmptyQuestionProgress();
  return {
    ...progress,
    questions: {
      ...progress.questions,
      [questionId]: {
        ...existing,
        marked: !existing.marked,
      },
    },
  };
}

export function clearWrongQuestion(progress: ProgressState, questionId: string) {
  const existing = progress.questions[questionId] ?? createEmptyQuestionProgress();
  return {
    ...progress,
    questions: {
      ...progress.questions,
      [questionId]: {
        ...existing,
        needsReview: false,
        correctStreak: Math.max(existing.correctStreak, 2),
      },
    },
  };
}

export function addExamSession(progress: ProgressState, exam: ExamSessionSummary) {
  return {
    ...progress,
    exams: [exam, ...progress.exams].slice(0, 20),
    streak: updateStreak(progress.streak),
  };
}

function createEmptyQuestionProgress(): QuestionProgress {
  return {
    attempts: 0,
    correct: 0,
    wrong: 0,
    correctStreak: 0,
    needsReview: false,
    marked: false,
    history: [],
  };
}

function migrateProgress(value: unknown): ProgressState {
  if (!value || typeof value !== "object") {
    return createEmptyProgress();
  }
  const maybe = value as Partial<ProgressState>;
  return {
    version: 1,
    questions: maybe.questions ?? {},
    exams: maybe.exams ?? [],
    streak: maybe.streak ?? { count: 0 },
  };
}

function updateStreak(streak: ProgressState["streak"]) {
  const today = localDateKey(new Date());
  if (streak.lastStudyDate === today) {
    return streak;
  }

  const yesterday = localDateKey(new Date(Date.now() - 24 * 60 * 60 * 1000));
  return {
    count: streak.lastStudyDate === yesterday ? streak.count + 1 : 1,
    lastStudyDate: today,
  };
}

function localDateKey(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}
