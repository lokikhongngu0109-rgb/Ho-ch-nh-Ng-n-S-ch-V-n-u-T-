import type { ProgressState, Question, QuestionFilters, QuestionProgress } from "../types/quiz";

export function getChapters(questions: Question[]) {
  return Array.from(
    questions.reduce((map, question) => {
      map.set(question.chapter, question.chapterTitle);
      return map;
    }, new Map<string, string>()),
    ([id, title]) => ({ id, title }),
  );
}

export function isWrongQuestion(record?: QuestionProgress) {
  return Boolean(record && record.needsReview && record.wrong > 0 && record.correctStreak < 2);
}

export function isAttempted(record?: QuestionProgress) {
  return Boolean(record && record.attempts > 0);
}

export function filterQuestions(
  questions: Question[],
  filters: QuestionFilters,
  progress?: ProgressState,
) {
  const search = normalize(filters.search ?? "");
  return questions.filter((question) => {
    const record = progress?.questions[question.id];

    if (filters.chapter && filters.chapter !== "all" && question.chapter !== filters.chapter) {
      return false;
    }

    if (filters.section && filters.section !== "all" && question.section !== filters.section) {
      return false;
    }

    if (filters.onlyUnseen && isAttempted(record)) {
      return false;
    }

    if (filters.onlyWrong && !isWrongQuestion(record)) {
      return false;
    }

    if (typeof filters.minWrong === "number" && (record?.wrong ?? 0) < filters.minWrong) {
      return false;
    }

    if (search) {
      const haystack = normalize(
        [
          question.id,
          question.sourceId,
          question.question,
          question.chapterTitle,
          question.topic ?? "",
          ...question.choices.map((choice) => choice.text),
        ].join(" "),
      );
      return haystack.includes(search);
    }

    return true;
  });
}

export function getWrongQuestions(questions: Question[], progress?: ProgressState) {
  return filterQuestions(questions, { onlyWrong: true }, progress);
}

export function getMarkedQuestions(questions: Question[], progress?: ProgressState) {
  if (!progress) {
    return [];
  }
  return questions.filter((question) => progress.questions[question.id]?.marked);
}

export function normalize(value: string) {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d")
    .trim();
}
