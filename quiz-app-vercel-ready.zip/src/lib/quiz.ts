import { filterQuestions } from "./filters";
import type { ChoiceKey, ProgressState, Question, StudyConfig } from "../types/quiz";

export function buildStudyQueue(
  questions: Question[],
  config: StudyConfig,
  progress?: ProgressState,
) {
  const filtered = filterQuestions(questions, config, progress);
  const ordered = config.shuffleQuestions ? shuffle(filtered) : filtered;
  return typeof config.amount === "number" && config.amount > 0
    ? ordered.slice(0, config.amount)
    : ordered;
}

export function shuffle<T>(items: T[]) {
  const copy = [...items];
  for (let index = copy.length - 1; index > 0; index -= 1) {
    const randomIndex = Math.floor(Math.random() * (index + 1));
    [copy[index], copy[randomIndex]] = [copy[randomIndex], copy[index]];
  }
  return copy;
}

export function orderedChoices(question: Question, shuffleAnswers = false) {
  return shuffleAnswers ? shuffle(question.choices) : question.choices;
}

export function answerState(
  option: ChoiceKey,
  correctAnswer: ChoiceKey,
  selectedAnswer?: ChoiceKey,
  reveal = false,
) {
  if (!reveal) {
    return selectedAnswer === option ? "selected" : "idle";
  }
  if (option === correctAnswer) {
    return "correct";
  }
  if (selectedAnswer === option && selectedAnswer !== correctAnswer) {
    return "wrong";
  }
  if (selectedAnswer === option) {
    return "selected";
  }
  return "idle";
}

export function shouldRevealAnswer(mode: "practice" | "exam", submitted: boolean) {
  return mode === "practice" || submitted;
}

export function parseNumberParam(value: string | null, fallback: number, max: number) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed <= 0) {
    return fallback;
  }
  return Math.min(Math.floor(parsed), max);
}
