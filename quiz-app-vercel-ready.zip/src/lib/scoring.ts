import { isAttempted, isWrongQuestion } from "./filters";
import type { ChoiceKey, ProgressState, Question, ScoreItem } from "../types/quiz";

export function scoreAnswers(
  questions: Question[],
  answers: Record<string, ChoiceKey | undefined>,
) {
  const items: ScoreItem[] = questions.map((question) => {
    const selectedAnswer = answers[question.id];
    return {
      question,
      selectedAnswer,
      isCorrect: selectedAnswer === question.correctAnswer,
    };
  });

  const correct = items.filter((item) => item.isCorrect).length;
  const unanswered = items.filter((item) => !item.selectedAnswer).length;
  const incorrect = questions.length - correct;

  return {
    total: questions.length,
    correct,
    incorrect,
    unanswered,
    percent: questions.length ? Math.round((correct / questions.length) * 100) : 0,
    items,
  };
}

export function summarizeProgress(questions: Question[], progress: ProgressState) {
  const attempted = questions.filter((question) => isAttempted(progress.questions[question.id])).length;
  const correctAttempts = Object.values(progress.questions).reduce((sum, record) => sum + record.correct, 0);
  const totalAttempts = Object.values(progress.questions).reduce((sum, record) => sum + record.attempts, 0);
  const wrongQuestions = questions.filter((question) => isWrongQuestion(progress.questions[question.id])).length;

  return {
    totalQuestions: questions.length,
    attempted,
    accuracy: totalAttempts ? Math.round((correctAttempts / totalAttempts) * 100) : 0,
    wrongQuestions,
    totalAttempts,
    streak: progress.streak.count,
  };
}

export function chapterStats(questions: Question[], progress: ProgressState) {
  const groups = new Map<string, Question[]>();
  for (const question of questions) {
    groups.set(question.chapter, [...(groups.get(question.chapter) ?? []), question]);
  }

  return Array.from(groups, ([chapter, chapterQuestions]) => {
    const attempts = chapterQuestions.reduce(
      (sum, question) => sum + (progress.questions[question.id]?.attempts ?? 0),
      0,
    );
    const correct = chapterQuestions.reduce(
      (sum, question) => sum + (progress.questions[question.id]?.correct ?? 0),
      0,
    );
    const attemptedQuestions = chapterQuestions.filter((question) =>
      isAttempted(progress.questions[question.id]),
    ).length;

    return {
      chapter,
      chapterTitle: chapterQuestions[0]?.chapterTitle ?? chapter,
      total: chapterQuestions.length,
      attemptedQuestions,
      attempts,
      correct,
      wrongQuestions: chapterQuestions.filter((question) =>
        isWrongQuestion(progress.questions[question.id]),
      ).length,
      accuracy: attempts ? Math.round((correct / attempts) * 100) : 0,
      completion: Math.round((attemptedQuestions / chapterQuestions.length) * 100),
    };
  });
}

export function weakestChapters(questions: Question[], progress: ProgressState, limit = 3) {
  return chapterStats(questions, progress)
    .filter((item) => item.attempts > 0)
    .sort((a, b) => a.accuracy - b.accuracy || b.wrongQuestions - a.wrongQuestions)
    .slice(0, limit);
}

export function mostMissedQuestions(questions: Question[], progress: ProgressState, limit = 8) {
  return questions
    .map((question) => ({ question, wrong: progress.questions[question.id]?.wrong ?? 0 }))
    .filter((item) => item.wrong > 0)
    .sort((a, b) => b.wrong - a.wrong)
    .slice(0, limit);
}
