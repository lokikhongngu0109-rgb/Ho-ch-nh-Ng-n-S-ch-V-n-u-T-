import type { Difficulty, QuestionSection } from "@/types/quiz";

export const sectionLabels: Record<QuestionSection, string> = {
  must_know: "Bắt buộc phải biết",
  easy_to_miss: "Dễ bỏ sót",
  supplement: "Bổ sung",
};

export const difficultyLabels: Record<Difficulty, string> = {
  basic: "Cơ bản",
  medium: "Trung bình",
  hard: "Khó",
};

export const sectionDescriptions: Record<QuestionSection, string> = {
  must_know: "Câu nền tảng cần nắm chắc trước kỳ thi.",
  easy_to_miss: "Câu dễ nhầm, nên luyện lại để tránh mất điểm.",
  supplement: "Câu tính toán và chủ đề bổ sung từ cuối tài liệu.",
};
