import type { Question } from "../types/quiz";

const VALID_ANSWERS = new Set(["A", "B", "C", "D", "E"]);

export function validateQuestionBank(questions: Question[]) {
  const errors: string[] = [];
  const seen = new Set<string>();

  for (const question of questions) {
    if (seen.has(question.id)) {
      errors.push(`${question.id}: duplicated id`);
    }
    seen.add(question.id);

    if (question.choices.length !== 5) {
      errors.push(`${question.id}: expected 5 choices, got ${question.choices.length}`);
    }

    if (!VALID_ANSWERS.has(question.correctAnswer)) {
      errors.push(`${question.id}: invalid answer ${question.correctAnswer}`);
    }

    if (!question.choices.some((choice) => choice.key === question.correctAnswer)) {
      errors.push(`${question.id}: answer key missing from choices`);
    }

    if (!question.question.trim()) {
      errors.push(`${question.id}: empty question`);
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}
