import type { Question } from "../types/quiz";

export const questions = [
  {
    "id": "C4-01",
    "sourceId": "C4.1",
    "chapter": "C4",
    "chapterTitle": "Định Giá Dòng Tiền Chiết Khấu",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "tính đến lãi trên lãi."
      },
      {
        "key": "B",
        "text": "là chi phí thực tế của khoản vay trả góp hàng tháng."
      },
      {
        "key": "C",
        "text": "cao hơn lãi suất hiệu dụng hàng năm khi lãi được tính gộp hàng quý."
      },
      {
        "key": "D",
        "text": "là lãi suất tính cho mỗi kỳ chia cho (1 + n), với n là số kỳ mỗi năm."
      },
      {
        "key": "E",
        "text": "bằng lãi suất hiệu dụng hàng năm khi lãi của tài khoản được xác định là lãi đơn."
      }
    ],
    "question": "Lãi suất phần trăm hàng năm (APR):",
    "correctAnswer": "E",
    "difficulty": "basic"
  },
  {
    "id": "C4-02",
    "sourceId": "C4.2",
    "chapter": "C4",
    "chapterTitle": "Định Giá Dòng Tiền Chiết Khấu",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "(1 + 0,09/365)^365"
      },
      {
        "key": "B",
        "text": "e^(0,09q)"
      },
      {
        "key": "C",
        "text": "1,09^e"
      },
      {
        "key": "D",
        "text": "e^(0,09) − 1"
      },
      {
        "key": "E",
        "text": "(1 + 0,09/365)^365 − 1"
      }
    ],
    "question": "Lãi suất hiệu dụng hàng năm cao nhất có thể đạt được từ APR = 9% được tính là:",
    "correctAnswer": "D",
    "difficulty": "basic"
  },
  {
    "id": "C4-03",
    "sourceId": "C4.3",
    "chapter": "C4",
    "chapterTitle": "Định Giá Dòng Tiền Chiết Khấu",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "79,97%"
      },
      {
        "key": "B",
        "text": "73,08%"
      },
      {
        "key": "C",
        "text": "51,21%"
      },
      {
        "key": "D",
        "text": "67,34%"
      },
      {
        "key": "E",
        "text": "83,43%"
      }
    ],
    "question": "Tiệm cầm đồ cộng thêm 2% vào số dư khoản vay cho mỗi hai tuần khoản vay tồn tại. Lãi suất hiệu dụng hàng năm (EAR) là bao nhiêu?",
    "correctAnswer": "D",
    "difficulty": "basic"
  },
  {
    "id": "C4-04",
    "sourceId": "C4.4",
    "chapter": "C4",
    "chapterTitle": "Định Giá Dòng Tiền Chiết Khấu",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Ngân hàng A: 3,75%, ghép lãi hàng năm"
      },
      {
        "key": "B",
        "text": "Ngân hàng B: 3,69%, ghép lãi hàng tháng"
      },
      {
        "key": "C",
        "text": "Ngân hàng C: 3,70%, ghép lãi nửa năm"
      },
      {
        "key": "D",
        "text": "Ngân hàng D: 3,67%, ghép lãi liên tục"
      },
      {
        "key": "E",
        "text": "Ngân hàng E: 3,65%, ghép lãi hàng quý"
      }
    ],
    "question": "Bạn có $2.500 để gửi tiết kiệm. Năm ngân hàng đưa ra các mức lãi sau. Nên gửi vào ngân hàng nào?",
    "correctAnswer": "B",
    "difficulty": "basic"
  },
  {
    "id": "C4-05",
    "sourceId": "C4.5",
    "chapter": "C4",
    "chapterTitle": "Định Giá Dòng Tiền Chiết Khấu",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "không có điều kiện nào để các dự án có giá trị bằng nhau."
      },
      {
        "key": "B",
        "text": "Dự án B có NPV cao hơn Dự án A."
      },
      {
        "key": "C",
        "text": "Dự án A có giá trị cao hơn Dự án B với tỷ lệ chiết khấu dương."
      },
      {
        "key": "D",
        "text": "cả hai dự án mang lại cùng tỷ suất sinh lợi."
      },
      {
        "key": "E",
        "text": "cả hai có NPV bằng nhau ở bất kỳ tỷ lệ chiết khấu nào."
      }
    ],
    "question": "Dự án A có dòng tiền $6.500, $4.500, $2.500 trong ba năm. Dự án B có $2.500, $4.500, $6.500. Cùng chi phí ban đầu. Bạn biết rằng:",
    "correctAnswer": "C",
    "difficulty": "basic"
  },
  {
    "id": "C4-06",
    "sourceId": "C4.6",
    "chapter": "C4",
    "chapterTitle": "Định Giá Dòng Tiền Chiết Khấu",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "tổng số tiền gốc được trả sẽ ít hơn dự kiến."
      },
      {
        "key": "B",
        "text": "khoản vay vẫn có số dư phải trả vào cuối kỳ 5 năm."
      },
      {
        "key": "C",
        "text": "khoản thanh toán đầu tiên trả nhiều gốc hơn dự kiến."
      },
      {
        "key": "D",
        "text": "lịch khấu hao dự kiến vẫn được áp dụng."
      },
      {
        "key": "E",
        "text": "các khoản thanh toán hàng năm sẽ cao hơn dự kiến."
      }
    ],
    "question": "Bạn vay $12.000 trong 5 năm với các khoản trả góp hàng năm bằng nhau. Nếu lãi suất thực tế cao hơn dự kiến, thì:",
    "correctAnswer": "E",
    "difficulty": "basic"
  },
  {
    "id": "C4-07",
    "sourceId": "C4.7",
    "chapter": "C4",
    "chapterTitle": "Định Giá Dòng Tiền Chiết Khấu",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "$10.466,67"
      },
      {
        "key": "B",
        "text": "$11.221,08"
      },
      {
        "key": "C",
        "text": "$9.416,75"
      },
      {
        "key": "D",
        "text": "$10.052,48"
      },
      {
        "key": "E",
        "text": "$8.949,60"
      }
    ],
    "question": "Marcos nhận khoản annuity $2.500, trả hai năm một lần, trong 10 năm tới. Khoản tiếp theo đến hạn sau 2 năm. Giá trị hiện tại với lãi suất 5% là:",
    "correctAnswer": "C",
    "trapNote": "C4.7 / B36: annuity trì hoãn → PVA cho giá trị tại 1 năm TRƯỚC dòng đầu, phải chiết khấu thêm về năm 0.",
    "difficulty": "basic"
  },
  {
    "id": "C4-08",
    "sourceId": "C4.8",
    "chapter": "C4",
    "chapterTitle": "Định Giá Dòng Tiền Chiết Khấu",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "$7.280,00"
      },
      {
        "key": "B",
        "text": "$7.311,62"
      },
      {
        "key": "C",
        "text": "$7.250,00"
      },
      {
        "key": "D",
        "text": "$6.924,32"
      },
      {
        "key": "E",
        "text": "$6.760,00"
      }
    ],
    "question": "Bạn đầu tư $6.500 trong 3 năm với LÃI ĐƠN 4%. Giá trị cuối kỳ là:",
    "correctAnswer": "A",
    "difficulty": "medium"
  },
  {
    "id": "C4-09",
    "sourceId": "C4.9",
    "chapter": "C4",
    "chapterTitle": "Định Giá Dòng Tiền Chiết Khấu",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "$132,45"
      },
      {
        "key": "B",
        "text": "$135,97"
      },
      {
        "key": "C",
        "text": "$128,89"
      },
      {
        "key": "D",
        "text": "$117,09"
      },
      {
        "key": "E",
        "text": "$121,67"
      }
    ],
    "question": "Beatrice đầu tư $1.000 với lãi đơn 5%. Cô kiếm được nhiều hơn bao nhiêu trong 10 năm nếu lãi được ghép hàng năm?",
    "correctAnswer": "C",
    "difficulty": "medium"
  },
  {
    "id": "C4-10",
    "sourceId": "C4.10",
    "chapter": "C4",
    "chapterTitle": "Định Giá Dòng Tiền Chiết Khấu",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "dựa quyết định đầu tư trên EAR và quyết định vay trên APR."
      },
      {
        "key": "B",
        "text": "giả định tất cả khoản vay và đầu tư dựa trên lãi đơn."
      },
      {
        "key": "C",
        "text": "chấp nhận khoản vay có EAR thấp hơn thay vì khoản vay có APR thấp hơn."
      },
      {
        "key": "D",
        "text": "đầu tư vào tài khoản 6% ghép hàng quý thay vì 6% ghép hàng tháng."
      },
      {
        "key": "E",
        "text": "bỏ qua EAR và tập trung vào APR cho mọi giao dịch."
      }
    ],
    "question": "Bạn sẽ đưa ra quyết định sáng suốt nếu:",
    "correctAnswer": "C",
    "difficulty": "medium"
  },
  {
    "id": "C4-11",
    "sourceId": "C4.11",
    "chapter": "C4",
    "chapterTitle": "Định Giá Dòng Tiền Chiết Khấu",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "7,90%"
      },
      {
        "key": "B",
        "text": "8,18%"
      },
      {
        "key": "C",
        "text": "8,20%"
      },
      {
        "key": "D",
        "text": "8,22%"
      },
      {
        "key": "E",
        "text": "8,39%"
      }
    ],
    "question": "Smart Bank niêm yết APR = 7,9%. Tỷ lệ tối đa thực sự ngân hàng có thể kiếm được dựa trên lãi suất niêm yết này là:",
    "correctAnswer": "D",
    "difficulty": "medium"
  },
  {
    "id": "C4-12",
    "sourceId": "C4.12",
    "chapter": "C4",
    "chapterTitle": "Định Giá Dòng Tiền Chiết Khấu",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Tăng chi phí ban đầu của một dự án sẽ làm tăng NPV."
      },
      {
        "key": "B",
        "text": "Tăng tỷ lệ chiết khấu sẽ làm tăng PV."
      },
      {
        "key": "C",
        "text": "Tăng FV sẽ làm giảm PV."
      },
      {
        "key": "D",
        "text": "Giảm PV sẽ làm giảm FV."
      },
      {
        "key": "E",
        "text": "Giảm tỷ lệ chiết khấu sẽ làm tăng FV."
      }
    ],
    "question": "Phát biểu nào sau đây là đúng về giá trị thời gian của tiền?",
    "correctAnswer": "D",
    "difficulty": "medium"
  },
  {
    "id": "C5-01",
    "sourceId": "C5.1",
    "chapter": "C5",
    "chapterTitle": "Npv Và Các Quy Tắc Đầu Tư",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "IRR chính là dương."
      },
      {
        "key": "B",
        "text": "IRR chính là âm."
      },
      {
        "key": "C",
        "text": "NPV bằng 0."
      },
      {
        "key": "D",
        "text": "mô hình dòng tiền có nhiều hơn một lần thay đổi dấu."
      },
      {
        "key": "E",
        "text": "mô hình dòng tiền có chính xác một lần thay đổi dấu."
      }
    ],
    "question": "Một dự án sẽ có nhiều hơn một IRR nếu, và chỉ nếu:",
    "correctAnswer": "D",
    "difficulty": "basic"
  },
  {
    "id": "C5-02",
    "sourceId": "C5.2",
    "chapter": "C5",
    "chapterTitle": "Npv Và Các Quy Tắc Đầu Tư",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "IRR gia tăng được tính khác cho các dự án tài trợ so với dự án đầu tư."
      },
      {
        "key": "B",
        "text": "quy tắc IRR cho dự án đầu tư ngược lại với quy tắc cho dự án tài trợ."
      },
      {
        "key": "C",
        "text": "tuổi thọ của dự án ảnh hưởng đến quyết định chọn dự án nào."
      },
      {
        "key": "D",
        "text": "quy tắc NPV cho dự án tài trợ ngược lại với quy tắc cho dự án đầu tư."
      },
      {
        "key": "E",
        "text": "chỉ số khả năng sinh lợi và NPV có liên quan."
      }
    ],
    "question": "So sánh hồ sơ NPV của dự án đầu tư với dự án tài trợ chứng minh tại sao:",
    "correctAnswer": "B",
    "trapNote": "C5.2: dự án TÀI TRỢ → quy tắc IRR đảo ngược (chấp nhận khi IRR < r).",
    "difficulty": "basic"
  },
  {
    "id": "C5-03",
    "sourceId": "C5.3",
    "chapter": "C5",
    "chapterTitle": "Npv Và Các Quy Tắc Đầu Tư",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "0"
      },
      {
        "key": "B",
        "text": "1"
      },
      {
        "key": "C",
        "text": "4"
      },
      {
        "key": "D",
        "text": "3"
      },
      {
        "key": "E",
        "text": "2"
      }
    ],
    "question": "Blue Bird Café xem xét dự án với chi phí ban đầu $46.800 và các dòng tiền $8.500, $25.000, $19.000 và −$4.500 cho Năm 1 đến Năm 4. Dự án này có bao nhiêu IRR?",
    "correctAnswer": "E",
    "difficulty": "basic"
  },
  {
    "id": "C5-04",
    "sourceId": "C5.4",
    "chapter": "C5",
    "chapterTitle": "Npv Và Các Quy Tắc Đầu Tư",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "4"
      },
      {
        "key": "B",
        "text": "3"
      },
      {
        "key": "C",
        "text": "5"
      },
      {
        "key": "D",
        "text": "6"
      },
      {
        "key": "E",
        "text": "2"
      }
    ],
    "question": "Một khoản đầu tư với chi phí ban đầu $4.000 tạo dòng tiền $3.400, −$500, $2.800, −$100 và $6.000 cho Năm 1 đến Năm 5. Dự án này có bao nhiêu IRR?",
    "correctAnswer": "C",
    "difficulty": "basic"
  },
  {
    "id": "C5-05",
    "sourceId": "C5.5",
    "chapter": "C5",
    "chapterTitle": "Npv Và Các Quy Tắc Đầu Tư",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "IRR cho dòng tiền của mỗi dự án."
      },
      {
        "key": "B",
        "text": "NPV của mỗi dự án sử dụng IRR làm tỷ lệ chiết khấu."
      },
      {
        "key": "C",
        "text": "tỷ lệ chiết khấu làm payback chiết khấu của mỗi dự án bằng nhau."
      },
      {
        "key": "D",
        "text": "tỷ lệ chiết khấu làm NPV của mỗi dự án bằng 1,0."
      },
      {
        "key": "E",
        "text": "IRR cho sự khác biệt trong dòng tiền của hai dự án."
      }
    ],
    "question": "Bạn tính IRR gia tăng cho hai dự án loại trừ lẫn nhau bằng cách xác định:",
    "correctAnswer": "E",
    "difficulty": "basic"
  },
  {
    "id": "C5-06",
    "sourceId": "C5.6",
    "chapter": "C5",
    "chapterTitle": "Npv Và Các Quy Tắc Đầu Tư",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "PV của các dòng tiền sau dòng tiền ban đầu bằng (−1 × Dòng tiền ban đầu)."
      },
      {
        "key": "B",
        "text": "Dự án có IRR bằng tỷ lệ chiết khấu."
      },
      {
        "key": "C",
        "text": "Dự án tạo thu nhập ròng bằng 0 mỗi năm."
      },
      {
        "key": "D",
        "text": "Các dòng tiền sau dòng tiền ban đầu có giá trị hiện tại bằng 0."
      },
      {
        "key": "E",
        "text": "Dự án có NPV bằng 0."
      }
    ],
    "question": "Chỉ số khả năng sinh lợi (PI) bằng 0 nên được hiểu như thế nào?",
    "correctAnswer": "D",
    "difficulty": "basic"
  },
  {
    "id": "C5-07",
    "sourceId": "C5.7",
    "chapter": "C5",
    "chapterTitle": "Npv Và Các Quy Tắc Đầu Tư",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "thời điểm của các dòng tiền không ảnh hưởng đến giá trị của dự án."
      },
      {
        "key": "B",
        "text": "dự án sẽ luôn được chấp nhận."
      },
      {
        "key": "C",
        "text": "dự án sẽ luôn bị từ chối."
      },
      {
        "key": "D",
        "text": "chấp nhận hay từ chối phụ thuộc vào thời điểm của các dòng tiền."
      },
      {
        "key": "E",
        "text": "dự án không bao giờ có thể tạo thêm giá trị cho cổ đông."
      }
    ],
    "question": "Nếu một dự án được ấn định tỷ suất sinh lợi yêu cầu bằng 0, thì:",
    "correctAnswer": "A",
    "difficulty": "medium"
  },
  {
    "id": "C5-08",
    "sourceId": "C5.8",
    "chapter": "C5",
    "chapterTitle": "Npv Và Các Quy Tắc Đầu Tư",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "được dùng làm tỷ lệ chiết khấu cho tất cả tính toán NPV."
      },
      {
        "key": "B",
        "text": "chỉ áp dụng cho các tính toán khả năng sinh lợi."
      },
      {
        "key": "C",
        "text": "được dùng để ra quyết định khi không thể ấn định tỷ lệ chiết khấu."
      },
      {
        "key": "D",
        "text": "được tính bằng cách kết hợp các dòng tiền cho đến khi chỉ còn một lần thay đổi dấu."
      },
      {
        "key": "E",
        "text": "giả định tất cả các dự án là dự án tài trợ."
      }
    ],
    "question": "Tỷ suất sinh lợi nội bộ sửa đổi (MIRR):",
    "correctAnswer": "D",
    "difficulty": "medium"
  },
  {
    "id": "C5-09",
    "sourceId": "C5.9",
    "chapter": "C5",
    "chapterTitle": "Npv Và Các Quy Tắc Đầu Tư",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Dự án tài trợ chỉ nên chấp nhận nếu NPV chính xác bằng 0."
      },
      {
        "key": "B",
        "text": "Dự án đầu tư chỉ nên chấp nhận nếu NPV bằng dòng tiền ban đầu."
      },
      {
        "key": "C",
        "text": "Bất kỳ loại dự án nào cũng nên chấp nhận nếu NPV dương và từ chối nếu NPV âm."
      },
      {
        "key": "D",
        "text": "Bất kỳ dự án nào có tổng dòng tiền vào lớn hơn tổng dòng tiền ra luôn nên chấp nhận."
      },
      {
        "key": "E",
        "text": "Dự án đầu tư có dòng tiền dương mọi kỳ sau đầu tư ban đầu nên được chấp nhận."
      }
    ],
    "question": "Phát biểu nào sau đây về NPV của dự án đầu tư hoặc dự án tài trợ là đúng?",
    "correctAnswer": "C",
    "difficulty": "medium"
  },
  {
    "id": "C5-10",
    "sourceId": "C5.10",
    "chapter": "C5",
    "chapterTitle": "Npv Và Các Quy Tắc Đầu Tư",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Lên kế hoạch xây nhà kho và cửa hàng bán lẻ cạnh nhau."
      },
      {
        "key": "B",
        "text": "Mua thiết bị để sản xuất đồng thời cả bàn và ghế."
      },
      {
        "key": "C",
        "text": "Cho thuê một nhà kho của công ty hoặc bán nó ngay."
      },
      {
        "key": "D",
        "text": "Dùng lực lượng bán hàng để thúc đẩy doanh số cả giày và tất."
      },
      {
        "key": "E",
        "text": "Mua cả hàng tồn kho và tài sản cố định bằng cùng một khoản vay."
      }
    ],
    "question": "Ví dụ nào sau đây là điển hình nhất về hai dự án loại trừ lẫn nhau?",
    "correctAnswer": "C",
    "difficulty": "medium"
  },
  {
    "id": "C6-01",
    "sourceId": "C6.1",
    "chapter": "C6",
    "chapterTitle": "Ra Quyết Định Đầu Tư Vốn",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "sự giảm trong khoản phải trả."
      },
      {
        "key": "B",
        "text": "sự gia tăng trong hàng tồn kho."
      },
      {
        "key": "C",
        "text": "sự giảm trong khoản phải thu."
      },
      {
        "key": "D",
        "text": "sự gia tăng trong số dư tài khoản séc."
      },
      {
        "key": "E",
        "text": "sự giảm trong tài sản cố định."
      }
    ],
    "question": "Vốn lưu động ròng (NWC) của một công ty sẽ GIẢM nếu có:",
    "correctAnswer": "C",
    "trapNote": "C6.1: giảm khoản PHẢI THU → NWC giảm; giảm phải TRẢ → NWC tăng.",
    "difficulty": "basic"
  },
  {
    "id": "C6-02",
    "sourceId": "C6.2",
    "chapter": "C6",
    "chapterTitle": "Ra Quyết Định Đầu Tư Vốn",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "$230.000(1 − 0,20 − 0,32)"
      },
      {
        "key": "B",
        "text": "$230.000[1 − (0,20)(0,32)]"
      },
      {
        "key": "C",
        "text": "$230.000(1 − 0,20)(1 − 0,32)"
      },
      {
        "key": "D",
        "text": "$230.000/(1 − 0,20 − 0,32)"
      },
      {
        "key": "E",
        "text": "$230.000(0,20)(0,32)"
      }
    ],
    "question": "Champion Toys mua tài sản MACRS 5-năm $230.000 (tỷ lệ 20%, 32%, 19,2%, 11,52%, 11,52%, 5,76%). Giá trị sổ sách cuối năm 2 được tính là:",
    "correctAnswer": "A",
    "difficulty": "basic"
  },
  {
    "id": "C6-03",
    "sourceId": "C6.3",
    "chapter": "C6",
    "chapterTitle": "Ra Quyết Định Đầu Tư Vốn",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "$1.661.500"
      },
      {
        "key": "B",
        "text": "$1.100.000"
      },
      {
        "key": "C",
        "text": "$1.208.635"
      },
      {
        "key": "D",
        "text": "$1.710.000"
      },
      {
        "key": "E",
        "text": "$1.498.000"
      }
    ],
    "question": "Marshall mua đất $498.000 cách đây 5 năm, chi thêm $63.500 san lấp, hiện định giá $610.000. Muốn xây cửa hàng $1,1 triệu. Dòng tiền ra ban đầu cho dự án là:",
    "correctAnswer": "D",
    "trapNote": "C6.3: chi phí cơ hội = giá trị thị trường HIỆN TẠI, không phải giá mua.",
    "difficulty": "basic"
  },
  {
    "id": "C6-04",
    "sourceId": "C6.4",
    "chapter": "C6",
    "chapterTitle": "Ra Quyết Định Đầu Tư Vốn",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "$27.500"
      },
      {
        "key": "B",
        "text": "$24.000"
      },
      {
        "key": "C",
        "text": "$31.300"
      },
      {
        "key": "D",
        "text": "$789.100"
      },
      {
        "key": "E",
        "text": "$900.700"
      }
    ],
    "question": "Walks Softly bán 14.800 đôi giày giá $59. Thêm dòng giày $39/đôi, kỳ vọng bán 6.000 đôi/năm nhưng sẽ giảm 3.500 đôi giày cũ. Doanh thu hàng năm nào nên dùng khi đánh giá dòng giày mới?",
    "correctAnswer": "A",
    "difficulty": "basic"
  },
  {
    "id": "C6-05",
    "sourceId": "C6.5",
    "chapter": "C6",
    "chapterTitle": "Ra Quyết Định Đầu Tư Vốn",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "$2.304"
      },
      {
        "key": "B",
        "text": "$2.507"
      },
      {
        "key": "C",
        "text": "$4.608"
      },
      {
        "key": "D",
        "text": "$0"
      },
      {
        "key": "E",
        "text": "$4.800"
      }
    ],
    "question": "Lee's mua $24.000 tài sản MACRS 5-năm, áp dụng khấu hao thưởng (bonus). Khấu hao năm thứ 3 là:",
    "correctAnswer": "D",
    "difficulty": "basic"
  },
  {
    "id": "C6-06",
    "sourceId": "C6.6",
    "chapter": "C6",
    "chapterTitle": "Ra Quyết Định Đầu Tư Vốn",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "$6.488,85"
      },
      {
        "key": "B",
        "text": "$8.880,20"
      },
      {
        "key": "C",
        "text": "$7.900,00"
      },
      {
        "key": "D",
        "text": "$7.770,40"
      },
      {
        "key": "E",
        "text": "$11.006,40"
      }
    ],
    "question": "Winslow mua $225.000 tài sản MACRS 5-năm, áp dụng khấu hao thưởng. Bán tài sản sau 4 năm với giá $10.000. Thuế 21%. Dòng tiền sau thuế từ việc bán là:",
    "correctAnswer": "C",
    "difficulty": "basic"
  },
  {
    "id": "C6-07",
    "sourceId": "C6.7",
    "chapter": "C6",
    "chapterTitle": "Ra Quyết Định Đầu Tư Vốn",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "yêu cầu vốn lưu động ròng ban đầu tăng."
      },
      {
        "key": "B",
        "text": "khấu hao giảm trong những năm đầu của vòng đời dự án."
      },
      {
        "key": "C",
        "text": "vòng đời của tài sản cố định được kéo dài."
      },
      {
        "key": "D",
        "text": "dòng tiền hoạt động tăng."
      },
      {
        "key": "E",
        "text": "thuế suất tăng."
      }
    ],
    "question": "Đối với một công ty phải nộp thuế, NPV của dự án sẽ TĂNG khi:",
    "correctAnswer": "D",
    "difficulty": "basic"
  },
  {
    "id": "C6-08",
    "sourceId": "C6.8",
    "chapter": "C6",
    "chapterTitle": "Ra Quyết Định Đầu Tư Vốn",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "sẽ có chi phí khấu hao bằng nhau mỗi năm."
      },
      {
        "key": "B",
        "text": "sẽ tính tỷ lệ lớn nhất của nguyên giá trong năm đầu."
      },
      {
        "key": "C",
        "text": "có thể khấu hao nguyên giá của đất đai."
      },
      {
        "key": "D",
        "text": "sẽ khấu hao toàn bộ nguyên giá trong suốt vòng đời phân loại của tài sản."
      },
      {
        "key": "E",
        "text": "không thể tính chi phí bất kỳ phần nào của nguyên giá trong năm đầu."
      }
    ],
    "question": "Một công ty từ bỏ khấu hao thưởng và dùng hệ thống MACRS:",
    "correctAnswer": "D",
    "difficulty": "medium"
  },
  {
    "id": "C6-09",
    "sourceId": "C6.9",
    "chapter": "C6",
    "chapterTitle": "Ra Quyết Định Đầu Tư Vốn",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "cả chi phí khấu hao và chi phí lãi vay đều bằng không."
      },
      {
        "key": "B",
        "text": "chi phí lãi vay bằng không."
      },
      {
        "key": "C",
        "text": "dự án là dự án cắt giảm chi phí."
      },
      {
        "key": "D",
        "text": "không yêu cầu tài sản cố định cho dự án."
      },
      {
        "key": "E",
        "text": "thuế được bỏ qua và chi phí lãi vay bằng không."
      }
    ],
    "question": "Phương pháp từ dưới lên (bottom-up) để tính dòng tiền hoạt động chỉ áp dụng khi:",
    "correctAnswer": "B",
    "difficulty": "medium"
  },
  {
    "id": "C6-10",
    "sourceId": "C6.10",
    "chapter": "C6",
    "chapterTitle": "Ra Quyết Định Đầu Tư Vốn",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "gia tăng"
      },
      {
        "key": "B",
        "text": "chìm"
      },
      {
        "key": "C",
        "text": "cơ hội"
      },
      {
        "key": "D",
        "text": "xói mòn"
      },
      {
        "key": "E",
        "text": "hàng năm tương đương"
      }
    ],
    "question": "Dòng thanh toán niên kim hàng năm có cùng giá trị hiện tại với chi phí của dự án được gọi là chi phí ________ của dự án.",
    "correctAnswer": "E",
    "difficulty": "medium"
  },
  {
    "id": "C6-11",
    "sourceId": "C6.11",
    "chapter": "C6",
    "chapterTitle": "Ra Quyết Định Đầu Tư Vốn",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "chỉ giá trị hiện tại ròng."
      },
      {
        "key": "B",
        "text": "cả giá trị hiện tại ròng và tỷ suất sinh lợi nội bộ."
      },
      {
        "key": "C",
        "text": "chi phí hàng năm tương đương của chúng."
      },
      {
        "key": "D",
        "text": "phương pháp lá chắn thuế khấu hao."
      },
      {
        "key": "E",
        "text": "phương pháp chi phí thay thế."
      }
    ],
    "question": "Toni's Tools so sánh các máy có giá khác nhau, chi phí vận hành khác nhau, tuổi thọ khác nhau và sẽ được thay thế khi hết hạn. Các máy này nên được so sánh bằng:",
    "correctAnswer": "C",
    "difficulty": "medium"
  },
  {
    "id": "C6-12",
    "sourceId": "C6.12",
    "chapter": "C6",
    "chapterTitle": "Ra Quyết Định Đầu Tư Vốn",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "chi phí khấu hao tăng."
      },
      {
        "key": "B",
        "text": "dự báo doanh thu bị hạ thấp."
      },
      {
        "key": "C",
        "text": "chi phí lãi vay được hạ thấp."
      },
      {
        "key": "D",
        "text": "yêu cầu vốn lưu động ròng tăng."
      },
      {
        "key": "E",
        "text": "lợi nhuận trước lãi vay và thuế giảm."
      }
    ],
    "question": "Dòng tiền hoạt động của một dự án sẽ TĂNG khi:",
    "correctAnswer": "A",
    "difficulty": "medium"
  },
  {
    "id": "C6-13",
    "sourceId": "C6.13",
    "chapter": "C6",
    "chapterTitle": "Ra Quyết Định Đầu Tư Vốn",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "$178.500"
      },
      {
        "key": "B",
        "text": "$120.000"
      },
      {
        "key": "C",
        "text": "$185.000"
      },
      {
        "key": "D",
        "text": "$192.900"
      },
      {
        "key": "E",
        "text": "$232.900"
      }
    ],
    "question": "Sue sở hữu căn nhà định giá $212.900, đang cho thuê, muốn chuyển thành văn phòng. Nếu bán, cô sẽ chịu $20.000 chi phí. Chi phí cơ hội của tài sản này là:",
    "correctAnswer": "D",
    "difficulty": "medium"
  },
  {
    "id": "C15-01",
    "sourceId": "C15.1",
    "chapter": "C15",
    "chapterTitle": "Phân Tích Độ Nhạy, Hòa Vốn, Kịch Bản",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "hoạt động"
      },
      {
        "key": "B",
        "text": "đòn bẩy"
      },
      {
        "key": "C",
        "text": "kế toán"
      },
      {
        "key": "D",
        "text": "tiền mặt"
      },
      {
        "key": "E",
        "text": "tài chính"
      }
    ],
    "question": "Mức doanh thu mà tại đó giá trị hiện tại ròng của dự án bằng đúng 0 được gọi là điểm hòa vốn ________.",
    "correctAnswer": "E",
    "difficulty": "basic"
  },
  {
    "id": "C15-02",
    "sourceId": "C15.2",
    "chapter": "C15",
    "chapterTitle": "Phân Tích Độ Nhạy, Hòa Vốn, Kịch Bản",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "lợi nhuận biên góp của công ty."
      },
      {
        "key": "B",
        "text": "phương pháp khấu hao."
      },
      {
        "key": "C",
        "text": "thuế suất."
      },
      {
        "key": "D",
        "text": "chi phí cố định."
      },
      {
        "key": "E",
        "text": "chi phí biến đổi trên mỗi đơn vị."
      }
    ],
    "question": "Điểm hòa vốn theo lợi nhuận kế toán KHÔNG bị ảnh hưởng bởi:",
    "correctAnswer": "C",
    "trapNote": "C15.2: thuế suất KHÔNG ảnh hưởng điểm hòa vốn kế toán. Thứ tự: Tiền mặt < Kế toán < Tài chính.",
    "difficulty": "basic"
  },
  {
    "id": "C15-03",
    "sourceId": "C15.3",
    "chapter": "C15",
    "chapterTitle": "Phân Tích Độ Nhạy, Hòa Vốn, Kịch Bản",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Sự gia tăng tài sản cố định ban đầu cần thiết cho một dự án sẽ làm tăng điểm hòa vốn kế toán."
      },
      {
        "key": "B",
        "text": "Nếu cần hạ điểm hòa vốn, công ty nên hạ ước tính doanh thu."
      },
      {
        "key": "C",
        "text": "NPV bằng 0 tại điểm hòa vốn kế toán."
      },
      {
        "key": "D",
        "text": "Sự gia tăng thuế suất sẽ làm tăng điểm hòa vốn kế toán."
      },
      {
        "key": "E",
        "text": "Khấu hao tài sản nhanh hơn sẽ làm giảm điểm hòa vốn kế toán."
      }
    ],
    "question": "Phát biểu nào sau đây là đúng?",
    "correctAnswer": "A",
    "difficulty": "basic"
  },
  {
    "id": "C15-04",
    "sourceId": "C15.4",
    "chapter": "C15",
    "chapterTitle": "Phân Tích Độ Nhạy, Hòa Vốn, Kịch Bản",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "xác định giá trị thanh lý của khoản đầu tư ban đầu."
      },
      {
        "key": "B",
        "text": "phân bổ khấu hao trong suốt vòng đời dự án."
      },
      {
        "key": "C",
        "text": "phân bổ khoản đầu tư ban đầu theo chi phí cơ hội của nó trong suốt vòng đời dự án."
      },
      {
        "key": "D",
        "text": "xác định tỷ lệ lợi nhuận biên góp trên chi phí cố định."
      },
      {
        "key": "E",
        "text": "phân bổ chi phí cơ hội và chi phí xói mòn trong suốt vòng đời dự án."
      }
    ],
    "question": "Trong phân tích hòa vốn giá trị hiện tại, EAC (Chi phí niên kim tương đương) được dùng để:",
    "correctAnswer": "C",
    "difficulty": "basic"
  },
  {
    "id": "C15-05",
    "sourceId": "C15.5",
    "chapter": "C15",
    "chapterTitle": "Phân Tích Độ Nhạy, Hòa Vốn, Kịch Bản",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "điểm lợi nhuận bằng không."
      },
      {
        "key": "B",
        "text": "điểm hòa vốn nội bộ."
      },
      {
        "key": "C",
        "text": "điểm hòa vốn kế toán."
      },
      {
        "key": "D",
        "text": "điểm hòa vốn tài chính."
      },
      {
        "key": "E",
        "text": "điểm hòa vốn thu nhập."
      }
    ],
    "question": "Điểm mà tại đó một dự án tạo ra tỷ suất sinh lợi bằng với tỷ suất sinh lợi yêu cầu được gọi là:",
    "correctAnswer": "D",
    "difficulty": "basic"
  },
  {
    "id": "C15-06",
    "sourceId": "C15.6",
    "chapter": "C15",
    "chapterTitle": "Phân Tích Độ Nhạy, Hòa Vốn, Kịch Bản",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "tăng giá trị khi độ nhạy của dự án với công nghệ mới tăng lên."
      },
      {
        "key": "B",
        "text": "độc lập với tỷ lệ chiết khấu của dự án."
      },
      {
        "key": "C",
        "text": "vô giá trị khi một dự án có lãi nếu được thực hiện ngay lập tức."
      },
      {
        "key": "D",
        "text": "làm giảm giá trị hiện tại ròng của dự án."
      },
      {
        "key": "E",
        "text": "có thể có giá trị ngay cả khi dự án hiện có giá trị hiện tại ròng âm."
      }
    ],
    "question": "Quyền chọn chờ đợi:",
    "correctAnswer": "E",
    "difficulty": "basic"
  },
  {
    "id": "C15-07",
    "sourceId": "C15.7",
    "chapter": "C15",
    "chapterTitle": "Phân Tích Độ Nhạy, Hòa Vốn, Kịch Bản",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "rủi ro dự báo của dự án càng thấp."
      },
      {
        "key": "B",
        "text": "phạm vi kết quả có thể xảy ra càng nhỏ."
      },
      {
        "key": "C",
        "text": "ban quản lý càng phải chú trọng nhiều hơn vào việc dự báo chính xác biến số đó."
      },
      {
        "key": "D",
        "text": "giá trị tiềm năng tối đa của dự án càng thấp."
      },
      {
        "key": "E",
        "text": "khoản lỗ tiềm năng tối đa của dự án càng thấp."
      }
    ],
    "question": "Khi mức độ nhạy cảm của một dự án với một biến số đơn lẻ tăng lên, thì:",
    "correctAnswer": "C",
    "difficulty": "medium"
  },
  {
    "id": "C15-08",
    "sourceId": "C15.8",
    "chapter": "C15",
    "chapterTitle": "Phân Tích Độ Nhạy, Hòa Vốn, Kịch Bản",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "liên quan trực tiếp đến chi phí lao động."
      },
      {
        "key": "B",
        "text": "được đo lường như chi phí trên một đơn vị thời gian."
      },
      {
        "key": "C",
        "text": "bị bỏ qua trong phân tích dự án."
      },
      {
        "key": "D",
        "text": "phụ thuộc vào số lượng hàng hóa hoặc dịch vụ được sản xuất."
      },
      {
        "key": "E",
        "text": "không liên quan khi tiến hành phân tích độ nhạy."
      }
    ],
    "question": "Chi phí sản xuất cố định:",
    "correctAnswer": "B",
    "difficulty": "medium"
  },
  {
    "id": "C15-09",
    "sourceId": "C15.9",
    "chapter": "C15",
    "chapterTitle": "Phân Tích Độ Nhạy, Hòa Vốn, Kịch Bản",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "phức tạp hơn để tính toán."
      },
      {
        "key": "B",
        "text": "bao gồm các chi phí cơ hội kinh tế của khoản đầu tư."
      },
      {
        "key": "C",
        "text": "tương đương với phân tích độ nhạy."
      },
      {
        "key": "D",
        "text": "bao gồm chi phí sản xuất cố định, điều mà hòa vốn kế toán không làm được."
      },
      {
        "key": "E",
        "text": "cung cấp lợi nhuận kinh tế vượt quá tỷ suất sinh lợi yêu cầu."
      }
    ],
    "question": "Điểm hòa vốn tài chính vượt trội hơn điểm hòa vốn kế toán vì phương pháp hòa vốn tài chính:",
    "correctAnswer": "B",
    "difficulty": "medium"
  },
  {
    "id": "C15-10",
    "sourceId": "C15.10",
    "chapter": "C15",
    "chapterTitle": "Phân Tích Độ Nhạy, Hòa Vốn, Kịch Bản",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "phân tích hoạt động."
      },
      {
        "key": "B",
        "text": "phân tích mô phỏng."
      },
      {
        "key": "C",
        "text": "phân tích tài chính."
      },
      {
        "key": "D",
        "text": "phân tích cây quyết định."
      },
      {
        "key": "E",
        "text": "phân tích độ nhạy."
      }
    ],
    "question": "Nếu bạn muốn có thông tin chi tiết nhất về kết quả tiềm năng của một dự án quan trọng, bạn nên tiến hành:",
    "correctAnswer": "B",
    "difficulty": "medium"
  },
  {
    "id": "C15-11",
    "sourceId": "C15.11",
    "chapter": "C15",
    "chapterTitle": "Phân Tích Độ Nhạy, Hòa Vốn, Kịch Bản",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Dự án chỉ đang thu hồi chi phí của khoản đầu tư ban đầu."
      },
      {
        "key": "B",
        "text": "Lợi nhuận sau thuế bằng với khoản đầu tư ban đầu."
      },
      {
        "key": "C",
        "text": "Dự án chỉ thu hồi vốn trên cơ sở chiết khấu."
      },
      {
        "key": "D",
        "text": "IRR của dự án bằng 0."
      },
      {
        "key": "E",
        "text": "Lợi nhuận biên góp bằng 0."
      }
    ],
    "question": "Phát biểu nào đúng khi một dự án hoạt động tại điểm hòa vốn theo lợi nhuận kế toán?",
    "correctAnswer": "A",
    "difficulty": "medium"
  },
  {
    "id": "C13-01",
    "sourceId": "C13.1",
    "chapter": "C13",
    "chapterTitle": "Rủi Ro, Chi Phí Vốn Và Định Giá",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "bằng beta thị trường."
      },
      {
        "key": "B",
        "text": "bằng một nửa beta vốn chủ sở hữu."
      },
      {
        "key": "C",
        "text": "bằng beta tài sản."
      },
      {
        "key": "D",
        "text": "bằng không."
      },
      {
        "key": "E",
        "text": "bằng một."
      }
    ],
    "question": "Beta của nợ thường được coi là:",
    "correctAnswer": "D",
    "difficulty": "basic"
  },
  {
    "id": "C13-02",
    "sourceId": "C13.2",
    "chapter": "C13",
    "chapterTitle": "Rủi Ro, Chi Phí Vốn Và Định Giá",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "gần tương đương với"
      },
      {
        "key": "B",
        "text": "nhỏ hơn đáng kể so với"
      },
      {
        "key": "C",
        "text": "nhỏ hơn một chút so với"
      },
      {
        "key": "D",
        "text": "lớn hơn so với"
      },
      {
        "key": "E",
        "text": "bằng với"
      }
    ],
    "question": "So sánh hai công ty tương đương về mọi mặt, beta cổ phiếu phổ thông của công ty CÓ đòn bẩy ________ beta của công ty KHÔNG đòn bẩy.",
    "correctAnswer": "D",
    "difficulty": "basic"
  },
  {
    "id": "C13-03",
    "sourceId": "C13.3",
    "chapter": "C13",
    "chapterTitle": "Rủi Ro, Chi Phí Vốn Và Định Giá",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "làm tăng cả beta tài sản và beta vốn chủ sở hữu."
      },
      {
        "key": "B",
        "text": "làm giảm cả beta tài sản và beta vốn chủ sở hữu."
      },
      {
        "key": "C",
        "text": "làm giảm beta vốn chủ sở hữu và tăng beta tài sản."
      },
      {
        "key": "D",
        "text": "làm tăng beta vốn chủ sở hữu nhưng không ảnh hưởng đến beta tài sản."
      },
      {
        "key": "E",
        "text": "làm giảm beta vốn chủ sở hữu nhưng không ảnh hưởng đến beta tài sản."
      }
    ],
    "question": "Việc sử dụng đòn bẩy:",
    "correctAnswer": "D",
    "difficulty": "basic"
  },
  {
    "id": "C13-04",
    "sourceId": "C13.4",
    "chapter": "C13",
    "chapterTitle": "Rủi Ro, Chi Phí Vốn Và Định Giá",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "ROA × Tỷ lệ chi trả cổ tức"
      },
      {
        "key": "B",
        "text": "ROE × Tỷ suất lợi nhuận"
      },
      {
        "key": "C",
        "text": "ROA × Tỷ lệ lợi nhuận giữ lại"
      },
      {
        "key": "D",
        "text": "ROA × Tỷ suất lợi nhuận"
      },
      {
        "key": "E",
        "text": "ROE × Tỷ lệ lợi nhuận giữ lại"
      }
    ],
    "question": "Cách tính tỷ lệ tăng trưởng kỳ vọng nào sau đây là đúng?",
    "correctAnswer": "E",
    "difficulty": "basic"
  },
  {
    "id": "C13-05",
    "sourceId": "C13.5",
    "chapter": "C13",
    "chapterTitle": "Rủi Ro, Chi Phí Vốn Và Định Giá",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "từ chối các dự án rủi ro nhất."
      },
      {
        "key": "B",
        "text": "chấp nhận tất cả các dự án rủi ro thấp."
      },
      {
        "key": "C",
        "text": "chỉ chấp nhận các dự án có rủi ro tương đương hoạt động hiện tại."
      },
      {
        "key": "D",
        "text": "duy trì ở mức rủi ro tổng thể hiện tại."
      },
      {
        "key": "E",
        "text": "trở nên rủi ro hơn theo thời gian."
      }
    ],
    "question": "Nếu một công ty áp dụng beta tổng thể của công ty cho các dự án có mức độ rủi ro khác nhau, công ty sẽ có xu hướng:",
    "correctAnswer": "E",
    "difficulty": "basic"
  },
  {
    "id": "C13-06",
    "sourceId": "C13.6",
    "chapter": "C13",
    "chapterTitle": "Rủi Ro, Chi Phí Vốn Và Định Giá",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "lợi suất đáo hạn ban đầu"
      },
      {
        "key": "B",
        "text": "lợi suất đáo hạn hiện tại"
      },
      {
        "key": "C",
        "text": "chi phí tích hợp"
      },
      {
        "key": "D",
        "text": "lợi suất hiện tại"
      },
      {
        "key": "E",
        "text": "lãi suất phiếu giảm giá (coupon)"
      }
    ],
    "question": "Chi phí trước thuế của khoản nợ mới được ước tính tốt nhất bằng ________ của khoản nợ hiện đang lưu hành.",
    "correctAnswer": "B",
    "trapNote": "C13.6: chi phí nợ mới = YTM HIỆN TẠI, không phải lãi suất coupon.",
    "difficulty": "basic"
  },
  {
    "id": "C13-07",
    "sourceId": "C13.7",
    "chapter": "C13",
    "chapterTitle": "Rủi Ro, Chi Phí Vốn Và Định Giá",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Chi phí vốn chủ sở hữu"
      },
      {
        "key": "B",
        "text": "Chi phí vốn cổ phần ưu đãi"
      },
      {
        "key": "C",
        "text": "Cả chi phí vốn chủ sở hữu và chi phí vốn cổ phần ưu đãi"
      },
      {
        "key": "D",
        "text": "Chi phí nợ và chi phí vốn cổ phần ưu đãi"
      },
      {
        "key": "E",
        "text": "Chi phí nợ"
      }
    ],
    "question": "Khi tính chi phí sử dụng vốn bình quân gia quyền (WACC), yếu tố nào được điều chỉnh theo thuế?",
    "correctAnswer": "E",
    "trapNote": "C13.7 / B27: chỉ CHI PHÍ NỢ được điều chỉnh thuế trong WACC.",
    "difficulty": "basic"
  },
  {
    "id": "C13-08",
    "sourceId": "C13.8",
    "chapter": "C13",
    "chapterTitle": "Rủi Ro, Chi Phí Vốn Và Định Giá",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "trừ chi phí phát hành trước thuế khỏi NPV của dự án."
      },
      {
        "key": "B",
        "text": "khấu trừ chi phí phát hành khỏi dòng tiền Năm 1."
      },
      {
        "key": "C",
        "text": "cộng tỷ lệ chi phí phát hành vào WACC khi chiết khấu."
      },
      {
        "key": "D",
        "text": "chia số vốn dự án cần thiết cho (1 − Chi phí phát hành bình quân gia quyền)."
      },
      {
        "key": "E",
        "text": "tăng trọng số mục tiêu của cả nợ và vốn chủ sở hữu."
      }
    ],
    "question": "Để hạch toán đúng chi phí phát hành, một công ty có vay nợ nên:",
    "correctAnswer": "D",
    "difficulty": "basic"
  },
  {
    "id": "C13-09",
    "sourceId": "C13.9",
    "chapter": "C13",
    "chapterTitle": "Rủi Ro, Chi Phí Vốn Và Định Giá",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "giá trị cổ tức cuối cùng."
      },
      {
        "key": "B",
        "text": "thuế suất của công ty."
      },
      {
        "key": "C",
        "text": "beta lịch sử."
      },
      {
        "key": "D",
        "text": "tốc độ tăng trưởng cổ tức."
      },
      {
        "key": "E",
        "text": "giá cổ phiếu hiện tại."
      }
    ],
    "question": "Khi ước tính chi phí vốn chủ sở hữu bằng DDM, yếu tố dễ gây sai số nhất là:",
    "correctAnswer": "D",
    "difficulty": "medium"
  },
  {
    "id": "C13-10",
    "sourceId": "C13.10",
    "chapter": "C13",
    "chapterTitle": "Rủi Ro, Chi Phí Vốn Và Định Giá",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Hoạt động kinh doanh mang tính chu kỳ cao và đòn bẩy hoạt động thấp"
      },
      {
        "key": "B",
        "text": "Hoạt động kinh doanh mang tính chu kỳ cao và đòn bẩy hoạt động cao"
      },
      {
        "key": "C",
        "text": "Hoạt động kinh doanh mang tính chu kỳ thấp và đòn bẩy tài chính thấp"
      },
      {
        "key": "D",
        "text": "Hoạt động kinh doanh mang tính chu kỳ thấp và đòn bẩy hoạt động thấp"
      },
      {
        "key": "E",
        "text": "Đòn bẩy tài chính thấp và đòn bẩy hoạt động thấp"
      }
    ],
    "question": "Beta của một công ty có nhiều khả năng cao hơn dưới hai điều kiện nào?",
    "correctAnswer": "B",
    "difficulty": "medium"
  },
  {
    "id": "C13-11",
    "sourceId": "C13.11",
    "chapter": "C13",
    "chapterTitle": "Rủi Ro, Chi Phí Vốn Và Định Giá",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Tăng trọng số của nợ"
      },
      {
        "key": "B",
        "text": "Giảm beta vốn chủ sở hữu của công ty"
      },
      {
        "key": "C",
        "text": "Giảm tốc độ tăng trưởng cổ tức"
      },
      {
        "key": "D",
        "text": "Giảm thuế suất"
      },
      {
        "key": "E",
        "text": "Tăng tỷ lệ phi rủi ro khi beta vốn chủ sở hữu vượt quá 1,0"
      }
    ],
    "question": "Giữ mọi thứ khác không đổi, yếu tố nào có nhiều khả năng làm TĂNG WACC của một công ty có đòn bẩy nhất?",
    "correctAnswer": "D",
    "difficulty": "medium"
  },
  {
    "id": "C13-12",
    "sourceId": "C13.12",
    "chapter": "C13",
    "chapterTitle": "Rủi Ro, Chi Phí Vốn Và Định Giá",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "hỗn hợp nợ và vốn chủ sở hữu sẽ dùng để tài trợ dự án cụ thể."
      },
      {
        "key": "B",
        "text": "cấu trúc vốn mục tiêu của công ty."
      },
      {
        "key": "C",
        "text": "tỷ lệ tài trợ nội bộ và bên ngoài sẽ dùng cho dự án."
      },
      {
        "key": "D",
        "text": "hỗn hợp nợ và vốn chủ sở hữu hiện tại của công ty."
      },
      {
        "key": "E",
        "text": "số vốn bên ngoài trung bình huy động trong 12 tháng qua."
      }
    ],
    "question": "Khi tính chi phí phát hành bình quân gia quyền, trọng số nên dựa trên:",
    "correctAnswer": "B",
    "difficulty": "medium"
  },
  {
    "id": "C13-13",
    "sourceId": "C13.13",
    "chapter": "C13",
    "chapterTitle": "Rủi Ro, Chi Phí Vốn Và Định Giá",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "được giả định bằng không."
      },
      {
        "key": "B",
        "text": "giống chi phí phát hành của vốn chủ sở hữu bên ngoài."
      },
      {
        "key": "C",
        "text": "bằng chi phí vốn chủ sở hữu sau thuế."
      },
      {
        "key": "D",
        "text": "bằng tỷ suất sinh lợi trên vốn chủ sở hữu của công ty."
      },
      {
        "key": "E",
        "text": "bằng tỷ lệ phi rủi ro."
      }
    ],
    "question": "Chi phí phát hành của vốn chủ sở hữu nội bộ là:",
    "correctAnswer": "A",
    "difficulty": "medium"
  },
  {
    "id": "C18-01",
    "sourceId": "C18.1",
    "chapter": "C18",
    "chapterTitle": "Định Giá & Lập Ngân Sách Vốn Cho Công Ty Có Vay Nợ",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Chiết khấu tất cả các dòng tiền từ dự án theo chi phí vốn tổng thể."
      },
      {
        "key": "B",
        "text": "Quy trình chiết khấu nhằm gia tăng quy mô."
      },
      {
        "key": "C",
        "text": "Chiết khấu các dòng tiền có đòn bẩy cho cổ đông theo tỷ suất sinh lợi yêu cầu trên vốn chủ sở hữu."
      },
      {
        "key": "D",
        "text": "Cổ tức và lợi vốn có thể chảy đến cổ đông của bất kỳ công ty nào."
      },
      {
        "key": "E",
        "text": "Chiết khấu các dòng tiền không đòn bẩy theo WACC."
      }
    ],
    "question": "Phương pháp dòng tiền vốn chủ sở hữu (FTE) trong lập ngân sách vốn được định nghĩa là:",
    "correctAnswer": "C",
    "difficulty": "basic"
  },
  {
    "id": "C18-02",
    "sourceId": "C18.2",
    "chapter": "C18",
    "chapterTitle": "Định Giá & Lập Ngân Sách Vốn Cho Công Ty Có Vay Nợ",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "chi phí vốn của công ty không vay nợ; đầu tư ban đầu; giá trị hiện tại điều chỉnh (APV)."
      },
      {
        "key": "B",
        "text": "chi phí vốn chủ sở hữu; đầu tư ban đầu; NPV của dự án."
      },
      {
        "key": "C",
        "text": "WACC; đầu tư vốn chủ sở hữu theo tỷ lệ; NPV của dự án."
      },
      {
        "key": "D",
        "text": "chi phí vốn của công ty không vay nợ; đầu tư ban đầu; NPV của công ty hoàn toàn bằng vốn chủ sở hữu."
      },
      {
        "key": "E",
        "text": "Không có đáp án nào ở trên."
      }
    ],
    "question": "Chiết khấu dòng tiền sau thuế không đòn bẩy bằng ______ trừ đi ______ sẽ cho ra ______.",
    "correctAnswer": "D",
    "difficulty": "basic"
  },
  {
    "id": "C18-03",
    "sourceId": "C18.3",
    "chapter": "C18",
    "chapterTitle": "Định Giá & Lập Ngân Sách Vốn Cho Công Ty Có Vay Nợ",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "chi phí vốn của công ty hoàn toàn bằng vốn chủ sở hữu."
      },
      {
        "key": "B",
        "text": "chi phí vốn chủ sở hữu của công ty có vay nợ."
      },
      {
        "key": "C",
        "text": "chi phí vốn không vay nợ trừ chi phí nợ bình quân gia quyền."
      },
      {
        "key": "D",
        "text": "chi phí vốn bình quân gia quyền (WACC)."
      },
      {
        "key": "E",
        "text": "chi phí vốn không vay nợ cộng chi phí nợ bình quân gia quyền."
      }
    ],
    "question": "Khi tính NPV bằng phương pháp dòng tiền vốn chủ sở hữu (FTE), tỷ lệ chiết khấu là:",
    "correctAnswer": "B",
    "difficulty": "basic"
  },
  {
    "id": "C18-04",
    "sourceId": "C18.4",
    "chapter": "C18",
    "chapterTitle": "Định Giá & Lập Ngân Sách Vốn Cho Công Ty Có Vay Nợ",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Mức nợ của dự án được xác định trong suốt vòng đời dự án."
      },
      {
        "key": "B",
        "text": "Tỷ lệ nợ trên giá trị mục tiêu của dự án không đổi suốt vòng đời."
      },
      {
        "key": "C",
        "text": "Việc tài trợ bằng nợ không xác định được suốt vòng đời dự án."
      },
      {
        "key": "D",
        "text": "Cả A và B."
      },
      {
        "key": "E",
        "text": "Cả B và C."
      }
    ],
    "question": "Phương pháp APV để định giá một dự án nên được sử dụng khi:",
    "correctAnswer": "A",
    "trapNote": "C18.4: APV dùng khi MỨC NỢ cố định; WACC/FTE khi TỶ LỆ D/V cố định.",
    "difficulty": "basic"
  },
  {
    "id": "C18-05",
    "sourceId": "C18.5",
    "chapter": "C18",
    "chapterTitle": "Định Giá & Lập Ngân Sách Vốn Cho Công Ty Có Vay Nợ",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "tính chi phí vốn chủ sở hữu bằng beta đã điều chỉnh rủi ro của một công ty khác trong NGÀNH trước khi tính WACC."
      },
      {
        "key": "B",
        "text": "tăng beta của một công ty khác trong cùng ngành rồi tính tỷ lệ chiết khấu bằng SML."
      },
      {
        "key": "C",
        "text": "chỉ cần áp dụng chi phí vốn hiện tại của mình."
      },
      {
        "key": "D",
        "text": "chiết khấu theo tỷ suất sinh lợi thị trường."
      },
      {
        "key": "E",
        "text": "tính chi phí vốn chủ sở hữu bằng beta của một công ty khác trong một NGÀNH KHÁC."
      }
    ],
    "question": "Để định giá một dự án không làm gia tăng quy mô (not scale enhancing), bạn cần:",
    "correctAnswer": "A",
    "difficulty": "basic"
  },
  {
    "id": "C18-06",
    "sourceId": "C18.6",
    "chapter": "C18",
    "chapterTitle": "Định Giá & Lập Ngân Sách Vốn Cho Công Ty Có Vay Nợ",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "WACC, IRR, và APV"
      },
      {
        "key": "B",
        "text": "NPV, IRR, và APV"
      },
      {
        "key": "C",
        "text": "NPV, APV và Flow to Debt"
      },
      {
        "key": "D",
        "text": "NPV, APV và WACC"
      },
      {
        "key": "E",
        "text": "APV, WACC, và Flow to Equity"
      }
    ],
    "question": "Các công cụ lập ngân sách vốn nào, nếu dùng đúng cách, sẽ cho ra cùng một đáp án?",
    "correctAnswer": "E",
    "difficulty": "basic"
  },
  {
    "id": "C18-07",
    "sourceId": "C18.7",
    "chapter": "C18",
    "chapterTitle": "Định Giá & Lập Ngân Sách Vốn Cho Công Ty Có Vay Nợ",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Cách tính toán các dòng tiền không đòn bẩy."
      },
      {
        "key": "B",
        "text": "Cách xác định tỷ lệ vốn chủ sở hữu trên nợ."
      },
      {
        "key": "C",
        "text": "Cách xử lý khoản đầu tư ban đầu."
      },
      {
        "key": "D",
        "text": "Liệu giá trị cuối kỳ có được bao gồm hay không."
      },
      {
        "key": "E",
        "text": "Cách xem xét các tác động của nợ (tỷ lệ D/V mục tiêu vs mức nợ)."
      }
    ],
    "question": "Một điểm khác biệt chính giữa các phương pháp APV, WACC và FTE là:",
    "correctAnswer": "E",
    "difficulty": "basic"
  },
  {
    "id": "C18-08",
    "sourceId": "C18.8",
    "chapter": "C18",
    "chapterTitle": "Định Giá & Lập Ngân Sách Vốn Cho Công Ty Có Vay Nợ",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Một nhóm nhỏ ban quản lý với nguồn tài trợ là vốn chủ sở hữu."
      },
      {
        "key": "B",
        "text": "Một nhóm nhỏ nhà đầu tư vốn chủ sở hữu, tài trợ phần lớn giá trị thương vụ bằng nợ vay."
      },
      {
        "key": "C",
        "text": "Bất kỳ nhóm nhà đầu tư nào khi phần lớn được tài trợ bằng cổ phiếu ưu đãi."
      },
      {
        "key": "D",
        "text": "Bất kỳ nhóm nhà đầu tư nào cho tài sản của tập đoàn."
      },
      {
        "key": "E",
        "text": "Không có đáp án nào ở trên."
      }
    ],
    "question": "Một thương vụ mua lại có sử dụng đòn bẩy (LBO) xảy ra khi một công ty được mua lại bởi:",
    "correctAnswer": "B",
    "difficulty": "medium"
  },
  {
    "id": "C18-09",
    "sourceId": "C18.9",
    "chapter": "C18",
    "chapterTitle": "Định Giá & Lập Ngân Sách Vốn Cho Công Ty Có Vay Nợ",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Trợ cấp thuế cho cổ tức, chi phí phát hành chứng khoán, trợ cấp kiệt quệ, chi phí tài trợ nợ."
      },
      {
        "key": "B",
        "text": "Chi phí phát hành chứng khoán, chi phí kiệt quệ tài chính, trợ cấp thuế cho nợ vay, các trợ cấp khác cho tài trợ nợ."
      },
      {
        "key": "C",
        "text": "Chi phí phát hành chứng khoán, chi phí kiệt quệ, trợ cấp thuế cho cổ tức, chi phí tài trợ nợ."
      },
      {
        "key": "D",
        "text": "Trợ cấp kiệt quệ, trợ cấp thuế cho nợ vay, chi phí tài trợ nợ khác, chi phí phát hành chứng khoán."
      },
      {
        "key": "E",
        "text": "Không có đáp án nào ở trên."
      }
    ],
    "question": "Phương pháp APV bao gồm NPV trong trường hợp hoàn toàn bằng vốn chủ sở hữu và NPV của các tác động tài trợ. Bốn tác động phụ là:",
    "correctAnswer": "B",
    "difficulty": "medium"
  },
  {
    "id": "C18-10",
    "sourceId": "C18.10",
    "chapter": "C18",
    "chapterTitle": "Định Giá & Lập Ngân Sách Vốn Cho Công Ty Có Vay Nợ",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "APV vì mức nợ không xác định được trong các năm tương lai."
      },
      {
        "key": "B",
        "text": "WACC vì các dự án có rủi ro không đổi và tỷ lệ nợ trên giá trị mục tiêu."
      },
      {
        "key": "C",
        "text": "Flow-to-equity vì rủi ro không đổi và nhà quản lý nghĩ theo tỷ lệ nợ trên vốn chủ sở hữu tối ưu."
      },
      {
        "key": "D",
        "text": "Cả A và B."
      },
      {
        "key": "E",
        "text": "Cả B và C."
      }
    ],
    "question": "Từ góc độ thực tiễn, các phương pháp hữu ích nhất là:",
    "correctAnswer": "E",
    "difficulty": "medium"
  },
  {
    "id": "C21-01",
    "sourceId": "C21.1",
    "chapter": "C21",
    "chapterTitle": "Thuê Tài Sản (Leasing)",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Hợp đồng thuê thường không được khấu hao hết."
      },
      {
        "key": "B",
        "text": "Bên đi thuê chịu trách nhiệm bảo trì tài sản thuê."
      },
      {
        "key": "C",
        "text": "Hợp đồng thuê thường không thể hủy ngang."
      },
      {
        "key": "D",
        "text": "Bên đi thuê thường có quyền gia hạn hợp đồng khi hết hạn."
      },
      {
        "key": "E",
        "text": "Bên đi thuê phải thanh toán tất cả các khoản tiền thuê."
      }
    ],
    "question": "Đặc điểm nào sau đây KHÔNG áp dụng cho thuê tài chính (financial lease)?",
    "correctAnswer": "A",
    "trapNote": "C21.1: thuê tài chính LÀ fully amortized (đáp án A = đặc điểm KHÔNG áp dụng).",
    "difficulty": "basic"
  },
  {
    "id": "C21-02",
    "sourceId": "C21.2",
    "chapter": "C21",
    "chapterTitle": "Thuê Tài Sản (Leasing)",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Bên cho thuê bảo trì tài sản thuê."
      },
      {
        "key": "B",
        "text": "Chi phí tài sản vượt quá các khoản thanh toán tiền thuê."
      },
      {
        "key": "C",
        "text": "Có điều khoản hủy ngang."
      },
      {
        "key": "D",
        "text": "Bên cho thuê phải thực hiện tất cả các khoản thanh toán."
      },
      {
        "key": "E",
        "text": "Được khấu hao hoàn toàn (fully amortized)."
      }
    ],
    "question": "Thuê tài chính (financial lease) có đặc điểm nào sau đây?",
    "correctAnswer": "E",
    "difficulty": "basic"
  },
  {
    "id": "C21-03",
    "sourceId": "C21.3",
    "chapter": "C21",
    "chapterTitle": "Thuê Tài Sản (Leasing)",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Thuê có đòn bẩy (leveraged lease)."
      },
      {
        "key": "B",
        "text": "Hợp đồng bán và thuê lại."
      },
      {
        "key": "C",
        "text": "Thuê vốn (capital lease)."
      },
      {
        "key": "D",
        "text": "Thuê không truy đòi (nonrecourse lease)."
      },
      {
        "key": "E",
        "text": "Thuê mua giá hời (bargain purchase lease)."
      }
    ],
    "question": "Nếu bên CHO THUÊ vay phần lớn giá mua tài sản cho thuê, hợp đồng này được gọi là:",
    "correctAnswer": "A",
    "difficulty": "basic"
  },
  {
    "id": "C21-04",
    "sourceId": "C21.4",
    "chapter": "C21",
    "chapterTitle": "Thuê Tài Sản (Leasing)",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Các khoản thanh toán tiền thuê sẽ chuyển trực tiếp cho người cho vay."
      },
      {
        "key": "B",
        "text": "Bên đi thuê có quyền thế chấp tài sản thuê đầu tiên."
      },
      {
        "key": "C",
        "text": "Bên cho thuê có nghĩa vụ thực hiện cả hợp đồng thuê và khoản vay."
      },
      {
        "key": "D",
        "text": "Bên đi thuê nhận nghĩa vụ khoản vay để đổi lấy quyền sở hữu tài sản."
      },
      {
        "key": "E",
        "text": "Hợp đồng thuê tự động bị hủy bỏ."
      }
    ],
    "question": "Thuê có đòn bẩy thường liên quan đến khoản vay không truy đòi — trong trường hợp vỡ nợ:",
    "correctAnswer": "A",
    "difficulty": "basic"
  },
  {
    "id": "C21-05",
    "sourceId": "C21.5",
    "chapter": "C21",
    "chapterTitle": "Thuê Tài Sản (Leasing)",
    "section": "must_know",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Một hợp đồng thuê hoạt động."
      },
      {
        "key": "B",
        "text": "Một hợp đồng thuê có đòn bẩy."
      },
      {
        "key": "C",
        "text": "Một hợp đồng bán và thuê lại (sale-leaseback)."
      },
      {
        "key": "D",
        "text": "Một hợp đồng thuê được khấu hao hoàn toàn."
      },
      {
        "key": "E",
        "text": "Cả thuê hoạt động và bán-thuê lại."
      }
    ],
    "question": "Thành phố bán cơ sở bảo trì, dùng tiền cải thiện tài chính, rồi thuê lại từ chủ mới trên cơ sở không thể hủy ngang và tự chịu trách nhiệm bảo trì. Đây là:",
    "correctAnswer": "C",
    "difficulty": "basic"
  },
  {
    "id": "C21-06",
    "sourceId": "C21.6",
    "chapter": "C21",
    "chapterTitle": "Thuê Tài Sản (Leasing)",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Thuê có đòn bẩy (leveraged lease)."
      },
      {
        "key": "B",
        "text": "Hợp đồng bán và thuê lại."
      },
      {
        "key": "C",
        "text": "Thuê vốn (capital lease)."
      },
      {
        "key": "D",
        "text": "Thuê kiểu bán hàng (sales-type lease)."
      },
      {
        "key": "E",
        "text": "Thuê giá hời (bargain lease)."
      }
    ],
    "question": "Nếu Alby thuê thiết bị trực tiếp từ NHÀ SẢN XUẤT thiết bị, hợp đồng đó phải là:",
    "correctAnswer": "D",
    "difficulty": "medium"
  },
  {
    "id": "C21-07",
    "sourceId": "C21.7",
    "chapter": "C21",
    "chapterTitle": "Thuê Tài Sản (Leasing)",
    "section": "easy_to_miss",
    "topic": null,
    "choices": [
      {
        "key": "A",
        "text": "Có thời hạn vượt quá vòng đời kinh tế của tài sản thuê."
      },
      {
        "key": "B",
        "text": "Được khấu hao hoàn toàn."
      },
      {
        "key": "C",
        "text": "Không thể hủy ngang."
      },
      {
        "key": "D",
        "text": "Yêu cầu bên đi thuê trả lại tài sản cho bên cho thuê nếu hợp đồng bị hủy."
      },
      {
        "key": "E",
        "text": "Yêu cầu bên đi thuê bảo trì tài sản thuê. PHẦN BỔ SUNG — 5 MẢNG CÒN THIẾU"
      }
    ],
    "question": "Thuê hoạt động (operating lease) thường:",
    "correctAnswer": "D",
    "difficulty": "medium"
  },
  {
    "id": "B01",
    "sourceId": "B1",
    "chapter": "SUP1",
    "chapterTitle": "Bổ sung 1: C5: THỜI GIAN HOÀN VỐN CHIẾT KHẤU (Discounted Payback)",
    "section": "supplement",
    "topic": "C5: THỜI GIAN HOÀN VỐN CHIẾT KHẤU (Discounted Payback)",
    "choices": [
      {
        "key": "A",
        "text": "giá trị hiện tại ròng."
      },
      {
        "key": "B",
        "text": "giá trị hiện tại ròng chiết khấu."
      },
      {
        "key": "C",
        "text": "thời gian hoàn vốn."
      },
      {
        "key": "D",
        "text": "chỉ số khả năng sinh lợi chiết khấu."
      },
      {
        "key": "E",
        "text": "thời gian hoàn vốn chiết khấu."
      }
    ],
    "question": "Khoảng thời gian cần thiết để các dòng tiền CHIẾT KHẤU của dự án bằng chi phí ban đầu được gọi là:",
    "correctAnswer": "E",
    "difficulty": "medium"
  },
  {
    "id": "B02",
    "sourceId": "B2",
    "chapter": "SUP1",
    "chapterTitle": "Bổ sung 1: C5: THỜI GIAN HOÀN VỐN CHIẾT KHẤU (Discounted Payback)",
    "section": "supplement",
    "topic": "C5: THỜI GIAN HOÀN VỐN CHIẾT KHẤU (Discounted Payback)",
    "choices": [
      {
        "key": "A",
        "text": "xem xét giá trị thời gian của tiền tệ."
      },
      {
        "key": "B",
        "text": "chiết khấu điểm cắt (cutoff)."
      },
      {
        "key": "C",
        "text": "chiết khấu chi phí ban đầu."
      },
      {
        "key": "D",
        "text": "được ưa chuộng hơn phương pháp NPV."
      },
      {
        "key": "E",
        "text": "bỏ qua rủi ro dự án."
      }
    ],
    "question": "So với thời gian hoàn vốn thường, phương pháp thời gian hoàn vốn chiết khấu:",
    "correctAnswer": "A",
    "difficulty": "medium"
  },
  {
    "id": "B03",
    "sourceId": "B3",
    "chapter": "SUP1",
    "chapterTitle": "Bổ sung 1: C5: THỜI GIAN HOÀN VỐN CHIẾT KHẤU (Discounted Payback)",
    "section": "supplement",
    "topic": "C5: THỜI GIAN HOÀN VỐN CHIẾT KHẤU (Discounted Payback)",
    "choices": [
      {
        "key": "A",
        "text": "các dự án có thời gian hoàn vốn chiết khấu vượt quá vòng đời dự án được chấp nhận."
      },
      {
        "key": "B",
        "text": "các dự án thanh khoản cao bị từ chối để ủng hộ dự án kém thanh khoản hơn."
      },
      {
        "key": "C",
        "text": "các dự án được chấp nhận sai do bỏ qua giá trị thời gian của tiền."
      },
      {
        "key": "D",
        "text": "một số dự án có NPV âm được chấp nhận."
      },
      {
        "key": "E",
        "text": "một số dự án có NPV dương bị từ chối."
      }
    ],
    "question": "Quy tắc thời gian hoàn vốn chiết khấu có thể gây ra:",
    "correctAnswer": "E",
    "difficulty": "medium"
  },
  {
    "id": "B04",
    "sourceId": "B4",
    "chapter": "SUP1",
    "chapterTitle": "Bổ sung 1: C5: THỜI GIAN HOÀN VỐN CHIẾT KHẤU (Discounted Payback)",
    "section": "supplement",
    "topic": "C5: THỜI GIAN HOÀN VỐN CHIẾT KHẤU (Discounted Payback)",
    "choices": [
      {
        "key": "A",
        "text": "tỷ lệ chiết khấu áp dụng cho dự án tăng lên."
      },
      {
        "key": "B",
        "text": "khoản chi tiền mặt ban đầu của dự án tăng lên."
      },
      {
        "key": "C",
        "text": "khoảng thời gian của dự án tăng lên."
      },
      {
        "key": "D",
        "text": "số tiền của mỗi dòng tiền vào tăng lên."
      },
      {
        "key": "E",
        "text": "chi phí tài sản cố định sử dụng trong dự án tăng lên."
      }
    ],
    "question": "Thời gian hoàn vốn chiết khấu của dự án sẽ GIẢM bất cứ khi nào:",
    "correctAnswer": "D",
    "difficulty": "medium"
  },
  {
    "id": "B05",
    "sourceId": "B5",
    "chapter": "SUP1",
    "chapterTitle": "Bổ sung 1: C5: THỜI GIAN HOÀN VỐN CHIẾT KHẤU (Discounted Payback)",
    "section": "supplement",
    "topic": "C5: THỜI GIAN HOÀN VỐN CHIẾT KHẤU (Discounted Payback)",
    "choices": [
      {
        "key": "A",
        "text": "2,65 năm"
      },
      {
        "key": "B",
        "text": "2,78 năm"
      },
      {
        "key": "C",
        "text": "2,94 năm"
      },
      {
        "key": "D",
        "text": "2,88 năm"
      },
      {
        "key": "E",
        "text": "Không bao giờ"
      }
    ],
    "question": "(Tính toán) Dự án có chi phí ban đầu $10.600, dòng tiền vào $3.700, $4.900, $2.500 cho Năm 1–3. Tỷ suất sinh lợi yêu cầu 7,5%. Thời gian hoàn vốn chiết khấu là:",
    "correctAnswer": "E",
    "trapNote": "B5/B7: hoàn vốn chiết khấu có thể là \"Không bao giờ\" nếu tổng PV dòng vào < chi phí ban đầu.",
    "difficulty": "hard"
  },
  {
    "id": "B06",
    "sourceId": "B6",
    "chapter": "SUP1",
    "chapterTitle": "Bổ sung 1: C5: THỜI GIAN HOÀN VỐN CHIẾT KHẤU (Discounted Payback)",
    "section": "supplement",
    "topic": "C5: THỜI GIAN HOÀN VỐN CHIẾT KHẤU (Discounted Payback)",
    "choices": [
      {
        "key": "A",
        "text": "2,76 năm"
      },
      {
        "key": "B",
        "text": "3,57 năm"
      },
      {
        "key": "C",
        "text": "3,42 năm"
      },
      {
        "key": "D",
        "text": "3,68 năm"
      },
      {
        "key": "E",
        "text": "2,92 năm"
      }
    ],
    "question": "(Tính toán) Dự án có chi phí ban đầu $382, dòng tiền $105, $130, $150, $150 cho Năm 1–4. Chi phí vốn 9%. Thời gian hoàn vốn chiết khấu là:",
    "correctAnswer": "B",
    "difficulty": "hard"
  },
  {
    "id": "B07",
    "sourceId": "B7",
    "chapter": "SUP1",
    "chapterTitle": "Bổ sung 1: C5: THỜI GIAN HOÀN VỐN CHIẾT KHẤU (Discounted Payback)",
    "section": "supplement",
    "topic": "C5: THỜI GIAN HOÀN VỐN CHIẾT KHẤU (Discounted Payback)",
    "choices": [
      {
        "key": "A",
        "text": "3,05 năm"
      },
      {
        "key": "B",
        "text": "2,68 năm"
      },
      {
        "key": "C",
        "text": "3,39 năm"
      },
      {
        "key": "D",
        "text": "2,21 năm"
      },
      {
        "key": "E",
        "text": "Không bao giờ"
      }
    ],
    "question": "(Tính toán) Homer xem xét dự án có dòng tiền vào $950/năm cho Năm 1–4, tỷ lệ chiết khấu yêu cầu 11%, chi phí ban đầu $2.100. Thời gian hoàn vốn chiết khấu là:",
    "correctAnswer": "B",
    "trapNote": "B5/B7: hoàn vốn chiết khấu có thể là \"Không bao giờ\" nếu tổng PV dòng vào < chi phí ban đầu.",
    "difficulty": "hard"
  },
  {
    "id": "B08",
    "sourceId": "B8",
    "chapter": "SUP2",
    "chapterTitle": "Bổ sung 2: C15: HÒA VỐN (TÍNH TOÁN) & CÂY QUYẾT ĐỊNH",
    "section": "supplement",
    "topic": "C15: HÒA VỐN (TÍNH TOÁN) & CÂY QUYẾT ĐỊNH",
    "choices": [
      {
        "key": "A",
        "text": "31.948 pound"
      },
      {
        "key": "B",
        "text": "32.467 pound"
      },
      {
        "key": "C",
        "text": "39.889 pound"
      },
      {
        "key": "D",
        "text": "42.650 pound"
      },
      {
        "key": "E",
        "text": "37.338 pound"
      }
    ],
    "question": "(Hòa vốn kế toán) Wilson's Meats có chi phí cố định $0,60/pound tại mức 32.500 pound, giá bán $3,89/pound, chi phí biến đổi $2,99/pound, khấu hao $16.400. Điểm hòa vốn kế toán là:",
    "correctAnswer": "C",
    "difficulty": "medium"
  },
  {
    "id": "B09",
    "sourceId": "B9",
    "chapter": "SUP2",
    "chapterTitle": "Bổ sung 2: C15: HÒA VỐN (TÍNH TOÁN) & CÂY QUYẾT ĐỊNH",
    "section": "supplement",
    "topic": "C15: HÒA VỐN (TÍNH TOÁN) & CÂY QUYẾT ĐỊNH",
    "choices": [
      {
        "key": "A",
        "text": "$142.734"
      },
      {
        "key": "B",
        "text": "$148.456"
      },
      {
        "key": "C",
        "text": "$110.025"
      },
      {
        "key": "D",
        "text": "$113.053"
      },
      {
        "key": "E",
        "text": "$122.082"
      }
    ],
    "question": "(Tìm khấu hao từ hòa vốn kế toán) Sản lượng hòa vốn kế toán là 35.173 đơn vị, chi phí cố định $318.290, lợi nhuận biên góp $13,27. Chi phí khấu hao là:",
    "correctAnswer": "B",
    "difficulty": "medium"
  },
  {
    "id": "B10",
    "sourceId": "B10",
    "chapter": "SUP2",
    "chapterTitle": "Bổ sung 2: C15: HÒA VỐN (TÍNH TOÁN) & CÂY QUYẾT ĐỊNH",
    "section": "supplement",
    "topic": "C15: HÒA VỐN (TÍNH TOÁN) & CÂY QUYẾT ĐỊNH",
    "choices": [
      {
        "key": "A",
        "text": "7.850"
      },
      {
        "key": "B",
        "text": "8.275"
      },
      {
        "key": "C",
        "text": "10.315"
      },
      {
        "key": "D",
        "text": "11.304"
      },
      {
        "key": "E",
        "text": "11.429"
      }
    ],
    "question": "(Hòa vốn kế toán/năm) Mini-Max có chi phí ban đầu $318.900, chi phí cố định hàng năm $45.200, chi phí biến đổi $16,78/đơn vị, giá bán $29,95, khấu hao đường thẳng 5 năm. Điểm hòa vốn kế toán mỗi năm là:",
    "correctAnswer": "B",
    "difficulty": "medium"
  },
  {
    "id": "B11",
    "sourceId": "B11",
    "chapter": "SUP2",
    "chapterTitle": "Bổ sung 2: C15: HÒA VỐN (TÍNH TOÁN) & CÂY QUYẾT ĐỊNH",
    "section": "supplement",
    "topic": "C15: HÒA VỐN (TÍNH TOÁN) & CÂY QUYẾT ĐỊNH",
    "choices": [
      {
        "key": "A",
        "text": "12.458"
      },
      {
        "key": "B",
        "text": "9.489"
      },
      {
        "key": "C",
        "text": "11.232"
      },
      {
        "key": "D",
        "text": "10.603"
      },
      {
        "key": "E",
        "text": "9.617"
      }
    ],
    "question": "(Hòa vốn giá trị hiện tại / tài chính) Dự án 1 năm có lợi nhuận biên góp $5, chi phí cố định $12.000, khấu hao $30.000, EAC $41.185, thuế suất 21%. Điểm hòa vốn giá trị hiện tại theo đơn vị là:",
    "correctAnswer": "C",
    "difficulty": "medium"
  },
  {
    "id": "B12",
    "sourceId": "B12",
    "chapter": "SUP2",
    "chapterTitle": "Bổ sung 2: C15: HÒA VỐN (TÍNH TOÁN) & CÂY QUYẾT ĐỊNH",
    "section": "supplement",
    "topic": "C15: HÒA VỐN (TÍNH TOÁN) & CÂY QUYẾT ĐỊNH",
    "choices": [
      {
        "key": "A",
        "text": "6.086"
      },
      {
        "key": "B",
        "text": "7.613"
      },
      {
        "key": "C",
        "text": "7.504"
      },
      {
        "key": "D",
        "text": "7.438"
      },
      {
        "key": "E",
        "text": "7.911"
      }
    ],
    "question": "(Hòa vốn tài chính, có tính EAC) Dự án cần đầu tư $148.000, chi phí cố định $39.800, lợi nhuận biên góp $14,62, thuế 21%, chiết khấu 15%, khấu hao đường thẳng 3 năm (EAC = $64.820,59). Điểm hòa vốn giá trị hiện tại mỗi năm là:",
    "correctAnswer": "D",
    "difficulty": "medium"
  },
  {
    "id": "B13",
    "sourceId": "B13",
    "chapter": "SUP2",
    "chapterTitle": "Bổ sung 2: C15: HÒA VỐN (TÍNH TOÁN) & CÂY QUYẾT ĐỊNH",
    "section": "supplement",
    "topic": "C15: HÒA VỐN (TÍNH TOÁN) & CÂY QUYẾT ĐỊNH",
    "choices": [
      {
        "key": "A",
        "text": "–$349,16"
      },
      {
        "key": "B",
        "text": "–$231,88"
      },
      {
        "key": "C",
        "text": "$108,17"
      },
      {
        "key": "D",
        "text": "$133,33"
      },
      {
        "key": "E",
        "text": "$147,59"
      }
    ],
    "question": "(Cây quyết định — làm ngược từ tương lai về hiện tại) Giai đoạn 2 của cây quyết định: nếu thành công, khoản thu $53.000 (xác suất 2/3); nếu thất bại, –$24.000 (xác suất 1/3). Chi phí để đến Giai đoạn 2 (1 năm sau) là $24.000. Chi phí vốn 15%. NPV của dự án ở Giai đoạn 1 là:",
    "correctAnswer": "B",
    "trapNote": "B13: cây quyết định → luôn làm NGƯỢC từ giai đoạn xa nhất về hiện tại.",
    "difficulty": "medium"
  },
  {
    "id": "B14",
    "sourceId": "B14",
    "chapter": "SUP3",
    "chapterTitle": "Bổ sung 3: C21: KẾ TOÁN & PHÂN LOẠI THUÊ THEO IRS",
    "section": "supplement",
    "topic": "C21: KẾ TOÁN & PHÂN LOẠI THUÊ THEO IRS",
    "choices": [
      {
        "key": "A",
        "text": "Bên đi thuê có thể mua tài sản theo giá trị thị trường hợp lý khi kết thúc hợp đồng."
      },
      {
        "key": "B",
        "text": "Hợp đồng thuê chuyển giao quyền sở hữu cho bên đi thuê khi kết thúc thời hạn."
      },
      {
        "key": "C",
        "text": "Thời hạn thuê bằng 60% hoặc hơn vòng đời kinh tế ước tính."
      },
      {
        "key": "D",
        "text": "Giá trị hiện tại của các khoản thuê bằng 75% giá trị thị trường hợp lý của tài sản."
      },
      {
        "key": "E",
        "text": "Bên cho thuê có thể gia hạn hợp đồng khi kết thúc thời hạn."
      }
    ],
    "question": "Điều kiện nào sau đây TỰ ĐỘNG làm cho hợp đồng thuê được phân loại là thuê vốn (capital lease) cho mục đích kế toán?",
    "correctAnswer": "B",
    "trapNote": "B14: điều kiện capital lease — PV khoản thuê ≥ 90% giá trị thị trường (KHÔNG phải 75%); đáp án D là bẫy.",
    "difficulty": "medium"
  },
  {
    "id": "B15",
    "sourceId": "B15",
    "chapter": "SUP3",
    "chapterTitle": "Bổ sung 3: C21: KẾ TOÁN & PHÂN LOẠI THUÊ THEO IRS",
    "section": "supplement",
    "topic": "C21: KẾ TOÁN & PHÂN LOẠI THUÊ THEO IRS",
    "choices": [
      {
        "key": "A",
        "text": "Cả bốn tiêu chí"
      },
      {
        "key": "B",
        "text": "Ba trong bốn tiêu chí bất kỳ"
      },
      {
        "key": "C",
        "text": "Hai trong bốn tiêu chí bất kỳ"
      },
      {
        "key": "D",
        "text": "Một trong bốn tiêu chí bất kỳ"
      },
      {
        "key": "E",
        "text": "Hai trong bốn tiêu chí, miễn là bên đi thuê có quyền sở hữu khi kết thúc"
      }
    ],
    "question": "FAS 13 đặt ra bốn tiêu chí để xác định thuê vốn. Cần đáp ứng bao nhiêu tiêu chí để được phân loại là thuê vốn?",
    "correctAnswer": "D",
    "difficulty": "medium"
  },
  {
    "id": "B16",
    "sourceId": "B16",
    "chapter": "SUP3",
    "chapterTitle": "Bổ sung 3: C21: KẾ TOÁN & PHÂN LOẠI THUÊ THEO IRS",
    "section": "supplement",
    "topic": "C21: KẾ TOÁN & PHÂN LOẠI THUÊ THEO IRS",
    "choices": [
      {
        "key": "A",
        "text": "$1.375.000; $1.375.000"
      },
      {
        "key": "B",
        "text": "$1.400.000; $1.180.000"
      },
      {
        "key": "C",
        "text": "$1.400.000; $1.400.000"
      },
      {
        "key": "D",
        "text": "$1.375.000; $1.155.000"
      },
      {
        "key": "E",
        "text": "$1.400.000; $1.155.000"
      }
    ],
    "question": "(Tính toán bảng cân đối) Fresh Fish có tài sản $1,2 triệu, nợ $0,98 triệu. Công ty thuê vốn thiết bị giá $200.000, giá trị hiện tại các khoản thuê là $175.000. Sau hợp đồng, bảng cân đối thể hiện tài sản ___ và nợ ___.",
    "correctAnswer": "D",
    "trapNote": "B16: thuê vốn → cộng PV khoản thuê ($175k) vào CẢ tài sản LẪN nợ.",
    "difficulty": "hard"
  },
  {
    "id": "B17",
    "sourceId": "B17",
    "chapter": "SUP3",
    "chapterTitle": "Bổ sung 3: C21: KẾ TOÁN & PHÂN LOẠI THUÊ THEO IRS",
    "section": "supplement",
    "topic": "C21: KẾ TOÁN & PHÂN LOẠI THUÊ THEO IRS",
    "choices": [
      {
        "key": "A",
        "text": "Thuê hoạt động vì vòng đời tài sản nhỏ hơn 10 năm."
      },
      {
        "key": "B",
        "text": "Thuê hoạt động vì không có sự giảm chi phí."
      },
      {
        "key": "C",
        "text": "Thuê có đòn bẩy vì được tài trợ bằng nợ."
      },
      {
        "key": "D",
        "text": "Thuê vốn vì thời hạn thuê lớn hơn 75% vòng đời kinh tế."
      },
      {
        "key": "E",
        "text": "Bán và thuê lại vì Sizzler's có toàn quyền sử dụng."
      }
    ],
    "question": "Sizzler's thuê tài sản $28.000 (vòng đời 6 năm) trong 5 năm. Hợp đồng được phân loại là:",
    "correctAnswer": "D",
    "difficulty": "medium"
  },
  {
    "id": "B18",
    "sourceId": "B18",
    "chapter": "SUP3",
    "chapterTitle": "Bổ sung 3: C21: KẾ TOÁN & PHÂN LOẠI THUÊ THEO IRS",
    "section": "supplement",
    "topic": "C21: KẾ TOÁN & PHÂN LOẠI THUÊ THEO IRS",
    "choices": [
      {
        "key": "A",
        "text": "Thuê tài chính."
      },
      {
        "key": "B",
        "text": "Thuê hoạt động."
      },
      {
        "key": "C",
        "text": "Thuê vốn."
      },
      {
        "key": "D",
        "text": "Bán có điều kiện (conditional sale)."
      },
      {
        "key": "E",
        "text": "Hợp đồng bán và thuê lại."
      }
    ],
    "question": "Nếu thời hạn thuê là 35 năm, IRS sẽ phân loại hợp đồng thuê đó là:",
    "correctAnswer": "D",
    "difficulty": "medium"
  },
  {
    "id": "B19",
    "sourceId": "B19",
    "chapter": "SUP3",
    "chapterTitle": "Bổ sung 3: C21: KẾ TOÁN & PHÂN LOẠI THUÊ THEO IRS",
    "section": "supplement",
    "topic": "C21: KẾ TOÁN & PHÂN LOẠI THUÊ THEO IRS",
    "choices": [
      {
        "key": "A",
        "text": "Hạn chế quyền phát hành nợ hoặc chi trả cổ tức của bên đi thuê."
      },
      {
        "key": "B",
        "text": "Đưa ra các tùy chọn gia hạn chỉ ở mức giá trị thị trường hợp lý."
      },
      {
        "key": "C",
        "text": "Trả tỷ suất sinh lợi rất thấp cho bên cho thuê."
      },
      {
        "key": "D",
        "text": "Chuyển giao quyền sở hữu khi kết thúc với giá thấp hơn giá thị trường hợp lý."
      },
      {
        "key": "E",
        "text": "Có thời hạn 30 năm hoặc hơn."
      }
    ],
    "question": "Để đáp ứng hướng dẫn của IRS về cho thuê, hợp đồng thuê nên:",
    "correctAnswer": "B",
    "difficulty": "medium"
  },
  {
    "id": "B20",
    "sourceId": "B20",
    "chapter": "SUP3",
    "chapterTitle": "Bổ sung 3: C21: KẾ TOÁN & PHÂN LOẠI THUÊ THEO IRS",
    "section": "supplement",
    "topic": "C21: KẾ TOÁN & PHÂN LOẠI THUÊ THEO IRS",
    "choices": [
      {
        "key": "A",
        "text": "Các công ty đi thuê thường không phải nộp thuế."
      },
      {
        "key": "B",
        "text": "Cho thuê thường dẫn đến phá sản."
      },
      {
        "key": "C",
        "text": "Hợp đồng thuê có thể được thiết lập chỉ để tránh thuế."
      },
      {
        "key": "D",
        "text": "Cho thuê dẫn đến tài trợ ngoại bảng."
      },
      {
        "key": "E",
        "text": "Các khoản thuê không bao giờ được khấu trừ như chi phí kinh doanh."
      }
    ],
    "question": "Một lý do chính khiến IRS quan tâm đến cấu trúc của hợp đồng thuê là vì:",
    "correctAnswer": "C",
    "difficulty": "medium"
  },
  {
    "id": "B21",
    "sourceId": "B21",
    "chapter": "SUP4",
    "chapterTitle": "Bổ sung 4: C13 & C18: CÂU TÍNH TOÁN (CAPM, BETA, WACC, APV)",
    "section": "supplement",
    "topic": "C13 & C18: CÂU TÍNH TOÁN (CAPM, BETA, WACC, APV)",
    "choices": [
      {
        "key": "A",
        "text": "6,80%"
      },
      {
        "key": "B",
        "text": "8,22%"
      },
      {
        "key": "C",
        "text": "9,54%"
      },
      {
        "key": "D",
        "text": "9,68%"
      },
      {
        "key": "E",
        "text": "8,46%"
      }
    ],
    "question": "(CAPM) Consolidated Transfer toàn vốn CSH, beta 0,75, phần bù rủi ro thị trường 7,78%, lãi suất phi rủi ro 3,84%. Tỷ suất sinh lợi kỳ vọng là:",
    "correctAnswer": "D",
    "difficulty": "hard"
  },
  {
    "id": "B22",
    "sourceId": "B22",
    "chapter": "SUP4",
    "chapterTitle": "Bổ sung 4: C13 & C18: CÂU TÍNH TOÁN (CAPM, BETA, WACC, APV)",
    "section": "supplement",
    "topic": "C13 & C18: CÂU TÍNH TOÁN (CAPM, BETA, WACC, APV)",
    "choices": [
      {
        "key": "A",
        "text": "13,1%"
      },
      {
        "key": "B",
        "text": "10,8%"
      },
      {
        "key": "C",
        "text": "12,8%"
      },
      {
        "key": "D",
        "text": "14,4%"
      },
      {
        "key": "E",
        "text": "13,6%"
      }
    ],
    "question": "(CAPM) Beta 1,2, lãi suất phi rủi ro 2,9%, tỷ suất sinh lợi thị trường kỳ vọng 11,4%. Chi phí vốn CSH là:",
    "correctAnswer": "A",
    "difficulty": "hard"
  },
  {
    "id": "B23",
    "sourceId": "B23",
    "chapter": "SUP4",
    "chapterTitle": "Bổ sung 4: C13 & C18: CÂU TÍNH TOÁN (CAPM, BETA, WACC, APV)",
    "section": "supplement",
    "topic": "C13 & C18: CÂU TÍNH TOÁN (CAPM, BETA, WACC, APV)",
    "choices": [
      {
        "key": "A",
        "text": "13,48%"
      },
      {
        "key": "B",
        "text": "12,29%"
      },
      {
        "key": "C",
        "text": "12,60%"
      },
      {
        "key": "D",
        "text": "11,68%"
      },
      {
        "key": "E",
        "text": "13,23%"
      }
    ],
    "question": "(DDM) Winslow trả cổ tức $1,35/cổ phiếu sau một năm, tăng 2,5%/năm. Giá hiện tại $14,70. Chi phí vốn CSH là:",
    "correctAnswer": "D",
    "difficulty": "medium"
  },
  {
    "id": "B24",
    "sourceId": "B24",
    "chapter": "SUP4",
    "chapterTitle": "Bổ sung 4: C13 & C18: CÂU TÍNH TOÁN (CAPM, BETA, WACC, APV)",
    "section": "supplement",
    "topic": "C13 & C18: CÂU TÍNH TOÁN (CAPM, BETA, WACC, APV)",
    "choices": [
      {
        "key": "A",
        "text": "0,70"
      },
      {
        "key": "B",
        "text": "0,44"
      },
      {
        "key": "C",
        "text": "0,62"
      },
      {
        "key": "D",
        "text": "0,67"
      },
      {
        "key": "E",
        "text": "0,59"
      }
    ],
    "question": "(Unlevering beta) RJ Corporation có chi phí vốn CSH 8,4%, tỷ lệ nợ/vốn CSH 0,6, tỷ suất sinh lợi thị trường 10,4%, lãi suất phi rủi ro 3,8%. Dùng giả định beta nợ thông thường, beta tài sản là:",
    "correctAnswer": "B",
    "difficulty": "hard"
  },
  {
    "id": "B25",
    "sourceId": "B25",
    "chapter": "SUP4",
    "chapterTitle": "Bổ sung 4: C13 & C18: CÂU TÍNH TOÁN (CAPM, BETA, WACC, APV)",
    "section": "supplement",
    "topic": "C13 & C18: CÂU TÍNH TOÁN (CAPM, BETA, WACC, APV)",
    "choices": [
      {
        "key": "A",
        "text": "0,88"
      },
      {
        "key": "B",
        "text": "1,23"
      },
      {
        "key": "C",
        "text": "0,97"
      },
      {
        "key": "D",
        "text": "1,19"
      },
      {
        "key": "E",
        "text": "1,06"
      }
    ],
    "question": "(Relevering beta — Hamada) HNT là công ty toàn vốn CSH với beta 0,88. Beta vốn CSH sẽ là bao nhiêu nếu công ty chuyển sang tỷ lệ nợ/vốn CSH 0,35? (giả định không thuế trong relever cơ bản)",
    "correctAnswer": "D",
    "trapNote": "B25: relever beta (Hamada): βL = βU × [1 + (1−T)×D/E]; nếu bỏ qua thuế → βL = βU(1 + D/E).",
    "difficulty": "hard"
  },
  {
    "id": "B26",
    "sourceId": "B26",
    "chapter": "SUP4",
    "chapterTitle": "Bổ sung 4: C13 & C18: CÂU TÍNH TOÁN (CAPM, BETA, WACC, APV)",
    "section": "supplement",
    "topic": "C13 & C18: CÂU TÍNH TOÁN (CAPM, BETA, WACC, APV)",
    "choices": [
      {
        "key": "A",
        "text": "0,52"
      },
      {
        "key": "B",
        "text": "0,59"
      },
      {
        "key": "C",
        "text": "0,82"
      },
      {
        "key": "D",
        "text": "0,77"
      },
      {
        "key": "E",
        "text": "0,63"
      }
    ],
    "question": "(Tìm D/E từ beta) Chi phí vốn CSH của BG là 9,4%, tỷ suất sinh lợi thị trường 13,6%, lãi suất phi rủi ro 3,8%, beta tài sản 0,36 (không cổ phiếu ưu đãi). Tỷ lệ nợ/vốn CSH là:",
    "correctAnswer": "B",
    "difficulty": "hard"
  },
  {
    "id": "B27",
    "sourceId": "B27",
    "chapter": "SUP4",
    "chapterTitle": "Bổ sung 4: C13 & C18: CÂU TÍNH TOÁN (CAPM, BETA, WACC, APV)",
    "section": "supplement",
    "topic": "C13 & C18: CÂU TÍNH TOÁN (CAPM, BETA, WACC, APV)",
    "choices": [
      {
        "key": "A",
        "text": "$428.571"
      },
      {
        "key": "B",
        "text": "$444.459"
      },
      {
        "key": "C",
        "text": "$565.547"
      },
      {
        "key": "D",
        "text": "$1.000.000"
      },
      {
        "key": "E",
        "text": "Không có đáp án đúng ở trên."
      }
    ],
    "question": "(C18 — NPV bằng WACC) Webster đầu tư kho mới chi phí ban đầu $1 triệu, giảm chi phí $100.000 vĩnh viễn. Tổng giá trị công ty $60 triệu, nợ $40 triệu. Chi phí nợ sau thuế 6%, chi phí vốn CSH 9%. NPV của dự án là: (Gợi ý: WACC = (40/60)(6%) + (20/60)(9%) = 7%; NPV = −1.000.000 + 100.000/0,07)",
    "correctAnswer": "A",
    "trapNote": "C13.7 / B27: chỉ CHI PHÍ NỢ được điều chỉnh thuế trong WACC.",
    "difficulty": "hard"
  },
  {
    "id": "B28",
    "sourceId": "B28",
    "chapter": "SUP4",
    "chapterTitle": "Bổ sung 4: C13 & C18: CÂU TÍNH TOÁN (CAPM, BETA, WACC, APV)",
    "section": "supplement",
    "topic": "C13 & C18: CÂU TÍNH TOÁN (CAPM, BETA, WACC, APV)",
    "choices": [
      {
        "key": "A",
        "text": "7,97%"
      },
      {
        "key": "B",
        "text": "8,96%"
      },
      {
        "key": "C",
        "text": "16,97%"
      },
      {
        "key": "D",
        "text": "17,96%"
      },
      {
        "key": "E",
        "text": "26,96%"
      }
    ],
    "question": "(C18 — Re có đòn bẩy) Tip-Top Paving có beta 1,11, chi phí nợ 11%, tỷ lệ nợ/giá trị 0,6, lãi suất phi rủi ro 9%, tỷ suất sinh lợi thị trường 16,18%. Chi phí vốn CSH là:",
    "correctAnswer": "C",
    "difficulty": "hard"
  },
  {
    "id": "B29",
    "sourceId": "B29",
    "chapter": "SUP4",
    "chapterTitle": "Bổ sung 4: C13 & C18: CÂU TÍNH TOÁN (CAPM, BETA, WACC, APV)",
    "section": "supplement",
    "topic": "C13 & C18: CÂU TÍNH TOÁN (CAPM, BETA, WACC, APV)",
    "choices": [
      {
        "key": "A",
        "text": "1,00"
      },
      {
        "key": "B",
        "text": "1,11"
      },
      {
        "key": "C",
        "text": "1,20"
      },
      {
        "key": "D",
        "text": "1,34"
      },
      {
        "key": "E",
        "text": "Không thể xác định."
      }
    ],
    "question": "(C18 — beta toàn công ty) Công ty được định giá $6 triệu, nợ $2 triệu, beta vốn CSH 1,8, beta nợ 0,42. Beta của toàn bộ công ty là:",
    "correctAnswer": "D",
    "difficulty": "hard"
  },
  {
    "id": "B30",
    "sourceId": "B30",
    "chapter": "SUP4",
    "chapterTitle": "Bổ sung 4: C13 & C18: CÂU TÍNH TOÁN (CAPM, BETA, WACC, APV)",
    "section": "supplement",
    "topic": "C13 & C18: CÂU TÍNH TOÁN (CAPM, BETA, WACC, APV)",
    "choices": [
      {
        "key": "A",
        "text": "$850.000"
      },
      {
        "key": "B",
        "text": "$1.200.000"
      },
      {
        "key": "C",
        "text": "$1.300.000"
      },
      {
        "key": "D",
        "text": "$1.650.000"
      },
      {
        "key": "E",
        "text": "Không có giá trị nào."
      }
    ],
    "question": "(C18 — giá trị tài trợ nợ trợ cấp) Telescoping Tube huy động $2.500.000 nợ vĩnh viễn lãi 11%, nhưng được Quận Albanic thu xếp lãi 8%. Thuế suất 34%. Tổng giá trị gia tăng từ tài trợ nợ (với khoản trợ cấp) là: (Gợi ý: NPV khoản vay = $2.500.000 − [0,08 × 2.500.000 × (1−0,34)]/0,11)",
    "correctAnswer": "C",
    "difficulty": "medium"
  },
  {
    "id": "B31",
    "sourceId": "B31",
    "chapter": "SUP5",
    "chapterTitle": "Bổ sung 5: C4: KHẤU HAO KHOẢN VAY & DÒNG TIỀN TĂNG TRƯỞNG",
    "section": "supplement",
    "topic": "C4: KHẤU HAO KHOẢN VAY & DÒNG TIỀN TĂNG TRƯỞNG",
    "choices": [
      {
        "key": "A",
        "text": "Cả hai annuity có giá trị bằng nhau hôm nay."
      },
      {
        "key": "B",
        "text": "Annuity của Allison là annuity đến hạn (annuity due)."
      },
      {
        "key": "C",
        "text": "Annuity của Ted có giá trị hiện tại cao hơn của Allison."
      },
      {
        "key": "D",
        "text": "Annuity của Allison có giá trị hiện tại cao hơn của Ted."
      },
      {
        "key": "E",
        "text": "Annuity của Ted là annuity thông thường (ordinary)."
      }
    ],
    "question": "Ted mua annuity trả $1.000/tháng trong 5 năm, nhận khoản đầu tiên HÔM NAY. Allison mua annuity trả $1.000/tháng trong 5 năm, nhận khoản đầu tiên SAU một tháng. Phát biểu nào đúng?",
    "correctAnswer": "C",
    "difficulty": "medium"
  },
  {
    "id": "B32",
    "sourceId": "B32",
    "chapter": "SUP5",
    "chapterTitle": "Bổ sung 5: C4: KHẤU HAO KHOẢN VAY & DÒNG TIỀN TĂNG TRƯỞNG",
    "section": "supplement",
    "topic": "C4: KHẤU HAO KHOẢN VAY & DÒNG TIỀN TĂNG TRƯỞNG",
    "choices": [
      {
        "key": "A",
        "text": "$10.961,36"
      },
      {
        "key": "B",
        "text": "$10.549,07"
      },
      {
        "key": "C",
        "text": "$8.533,84"
      },
      {
        "key": "D",
        "text": "$8.686,82"
      },
      {
        "key": "E",
        "text": "$8.342,05"
      }
    ],
    "question": "(Khấu hao khoản vay — mua xe trả góp) Olivia trả $185/tháng trong 4 năm, lãi 4,9% ghép hàng tháng, trả trước $2.500. Cô có thể mua chiếc xe giá bao nhiêu?",
    "correctAnswer": "B",
    "difficulty": "medium"
  },
  {
    "id": "B33",
    "sourceId": "B33",
    "chapter": "SUP5",
    "chapterTitle": "Bổ sung 5: C4: KHẤU HAO KHOẢN VAY & DÒNG TIỀN TĂNG TRƯỞNG",
    "section": "supplement",
    "topic": "C4: KHẤU HAO KHOẢN VAY & DÒNG TIỀN TĂNG TRƯỞNG",
    "choices": [
      {
        "key": "A",
        "text": "$17.189,19"
      },
      {
        "key": "B",
        "text": "$19.960,00"
      },
      {
        "key": "C",
        "text": "$27.272,73"
      },
      {
        "key": "D",
        "text": "$24.609,11"
      },
      {
        "key": "E",
        "text": "$30.388,18"
      }
    ],
    "question": "(Dòng tiền vĩnh viễn tăng trưởng) Quỹ tín thác tài trợ học bổng vĩnh viễn; khoản phân phối kế tiếp $1.200, tăng 3%/năm. Tỷ lệ chiết khấu 7,4%. Giá trị quỹ là:",
    "correctAnswer": "C",
    "difficulty": "medium"
  },
  {
    "id": "B34",
    "sourceId": "B34",
    "chapter": "SUP5",
    "chapterTitle": "Bổ sung 5: C4: KHẤU HAO KHOẢN VAY & DÒNG TIỀN TĂNG TRƯỞNG",
    "section": "supplement",
    "topic": "C4: KHẤU HAO KHOẢN VAY & DÒNG TIỀN TĂNG TRƯỞNG",
    "choices": [
      {
        "key": "A",
        "text": "2,45%"
      },
      {
        "key": "B",
        "text": "3,10%"
      },
      {
        "key": "C",
        "text": "2,80%"
      },
      {
        "key": "D",
        "text": "2,50%"
      },
      {
        "key": "E",
        "text": "2,95%"
      }
    ],
    "question": "(Tìm tỷ lệ tăng trưởng g) Một dòng tiền vĩnh viễn tăng trưởng được định giá $6.225,81. Khoản thanh toán kế tiếp $386, tỷ lệ chiết khấu 9%. Tỷ lệ tăng trưởng là:",
    "correctAnswer": "C",
    "difficulty": "medium"
  },
  {
    "id": "B35",
    "sourceId": "B35",
    "chapter": "SUP5",
    "chapterTitle": "Bổ sung 5: C4: KHẤU HAO KHOẢN VAY & DÒNG TIỀN TĂNG TRƯỞNG",
    "section": "supplement",
    "topic": "C4: KHẤU HAO KHOẢN VAY & DÒNG TIỀN TĂNG TRƯỞNG",
    "choices": [
      {
        "key": "A",
        "text": "$638.724,17"
      },
      {
        "key": "B",
        "text": "$602.409,91"
      },
      {
        "key": "C",
        "text": "$558.845,85"
      },
      {
        "key": "D",
        "text": "$630.500,00"
      },
      {
        "key": "E",
        "text": "$525.000,00"
      }
    ],
    "question": "(Annuity tăng trưởng — lương tăng) Scott được đề nghị hợp đồng 10 năm, lương khởi điểm $65.000, tăng 5%/năm. Giá trị hiện tại với tỷ lệ chiết khấu 7% là:",
    "correctAnswer": "C",
    "difficulty": "medium"
  },
  {
    "id": "B36",
    "sourceId": "B36",
    "chapter": "SUP5",
    "chapterTitle": "Bổ sung 5: C4: KHẤU HAO KHOẢN VAY & DÒNG TIỀN TĂNG TRƯỞNG",
    "section": "supplement",
    "topic": "C4: KHẤU HAO KHOẢN VAY & DÒNG TIỀN TĂNG TRƯỞNG",
    "choices": [
      {
        "key": "A",
        "text": "$4.209,19"
      },
      {
        "key": "B",
        "text": "$4.774,04"
      },
      {
        "key": "C",
        "text": "$3.961,80"
      },
      {
        "key": "D",
        "text": "$4.887,48"
      },
      {
        "key": "E",
        "text": "$4.111,08"
      }
    ],
    "question": "(Annuity trì hoãn — deferred) Christina nhận annuity $1.200/năm trong 5 năm, khoản đầu tiên vào Năm 4. Giá trị hôm nay với tỷ lệ chiết khấu 7,25% là:",
    "correctAnswer": "C",
    "trapNote": "C4.7 / B36: annuity trì hoãn → PVA cho giá trị tại 1 năm TRƯỚC dòng đầu, phải chiết khấu thêm về năm 0.",
    "difficulty": "medium"
  }
] satisfies Question[];

export const QUESTION_BANK_SOURCE = {
  title: "Hoạch định Ngân sách Vốn Đầu tư",
  sourceFile: "file trắc nghiệm hđ.docx",
  totalQuestions: 112,
  answerSource: "ĐÁP ÁN ĐẦY ĐỦ",
} as const;
