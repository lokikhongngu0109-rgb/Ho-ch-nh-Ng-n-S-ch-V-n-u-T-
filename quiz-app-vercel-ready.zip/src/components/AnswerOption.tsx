import type { ChoiceKey } from "@/types/quiz";
import { cn } from "@/lib/cn";

const stateClasses = {
  idle: "border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950 dark:hover:bg-slate-900",
  selected:
    "border-amber-400 bg-amber-50 text-amber-950 dark:border-amber-500 dark:bg-amber-950/40 dark:text-amber-50",
  correct:
    "border-teal-500 bg-teal-50 text-teal-950 dark:border-teal-500 dark:bg-teal-950/40 dark:text-teal-50",
  wrong:
    "border-rose-500 bg-rose-50 text-rose-950 dark:border-rose-500 dark:bg-rose-950/40 dark:text-rose-50",
};

export function AnswerOption({
  choiceKey,
  text,
  state,
  disabled,
  onSelect,
}: {
  choiceKey: ChoiceKey;
  text: string;
  state: keyof typeof stateClasses;
  disabled?: boolean;
  onSelect: () => void;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onSelect}
      className={cn(
        "grid w-full grid-cols-[2.25rem_1fr] gap-3 rounded-lg border p-3 text-left text-sm leading-6 shadow-sm transition disabled:cursor-default",
        stateClasses[state],
      )}
    >
      <span className="flex h-9 w-9 items-center justify-center rounded-md border border-current/20 bg-white/70 font-semibold dark:bg-slate-900/60">
        {choiceKey}
      </span>
      <span className="min-w-0 self-center text-slate-800 dark:text-slate-100">{text}</span>
    </button>
  );
}
