import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

const toneClasses = {
  teal: "border-teal-200 bg-teal-50 text-teal-950 dark:border-teal-800 dark:bg-teal-950/40 dark:text-teal-50",
  amber:
    "border-amber-200 bg-amber-50 text-amber-950 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-50",
  rose: "border-rose-200 bg-rose-50 text-rose-950 dark:border-rose-800 dark:bg-rose-950/40 dark:text-rose-50",
  slate:
    "border-slate-200 bg-white text-slate-950 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-100",
} as const;

export function MetricCard({
  label,
  value,
  detail,
  icon,
  tone = "slate",
}: {
  label: string;
  value: string | number;
  detail?: string;
  icon?: ReactNode;
  tone?: keyof typeof toneClasses;
}) {
  return (
    <section className={cn("rounded-lg border p-4 shadow-sm", toneClasses[tone])}>
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-sm font-medium opacity-75">{label}</p>
          <p className="mt-2 text-3xl font-semibold leading-none">{value}</p>
        </div>
        {icon ? <div className="rounded-md bg-white/70 p-2 dark:bg-slate-900/60">{icon}</div> : null}
      </div>
      {detail ? <p className="mt-3 text-sm opacity-75">{detail}</p> : null}
    </section>
  );
}
