"use client";

import { Clock } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

export function Timer({
  durationSeconds,
  running,
  onExpire,
}: {
  durationSeconds: number;
  running: boolean;
  onExpire: () => void;
}) {
  const [remaining, setRemaining] = useState(durationSeconds);

  useEffect(() => {
    if (!running) {
      return;
    }
    const interval = window.setInterval(() => {
      setRemaining((current) => {
        if (current <= 1) {
          window.clearInterval(interval);
          onExpire();
          return 0;
        }
        return current - 1;
      });
    }, 1000);
    return () => window.clearInterval(interval);
  }, [onExpire, running]);

  const label = useMemo(() => {
    const minutes = Math.floor(remaining / 60);
    const seconds = String(remaining % 60).padStart(2, "0");
    return `${minutes}:${seconds}`;
  }, [remaining]);

  return (
    <div className="inline-flex h-10 items-center gap-2 rounded-md border border-slate-200 bg-white px-3 text-sm font-semibold text-slate-800 shadow-sm dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100">
      <Clock aria-hidden size={16} />
      {label}
    </div>
  );
}
