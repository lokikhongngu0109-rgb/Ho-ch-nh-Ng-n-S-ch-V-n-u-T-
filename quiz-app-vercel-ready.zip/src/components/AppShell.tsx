"use client";

import {
  BarChart3,
  BookOpenCheck,
  ClipboardList,
  LayoutDashboard,
  RotateCcw,
  Search,
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import { cn } from "@/lib/cn";
import { ThemeToggle } from "@/components/ThemeToggle";

const navItems = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/practice", label: "Luyện tập", icon: BookOpenCheck },
  { href: "/exam", label: "Thi thử", icon: ClipboardList },
  { href: "/review", label: "Câu sai", icon: RotateCcw },
  { href: "/questions", label: "Ngân hàng", icon: Search },
  { href: "/progress", label: "Tiến độ", icon: BarChart3 },
];

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();

  return (
    <div className="min-h-screen bg-slate-50 text-slate-950 dark:bg-slate-950 dark:text-slate-100">
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur dark:border-slate-800 dark:bg-slate-950/95">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-4 lg:px-6">
          <div className="flex items-start justify-between gap-4">
            <Link href="/" className="min-w-0">
              <p className="text-sm font-semibold uppercase tracking-[0.16em] text-teal-700 dark:text-teal-300">
                Capital Budgeting Quiz
              </p>
              <h1 className="mt-1 text-xl font-semibold leading-tight text-slate-950 dark:text-white sm:text-2xl">
                Hoạch định Ngân sách Vốn Đầu tư
              </h1>
            </Link>
            <ThemeToggle />
          </div>

          <nav className="flex gap-2 overflow-x-auto pb-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = pathname === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "inline-flex h-10 shrink-0 items-center gap-2 rounded-md border px-3 text-sm font-medium transition",
                    active
                      ? "border-teal-600 bg-teal-600 text-white shadow-sm"
                      : "border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800",
                  )}
                >
                  <Icon aria-hidden size={16} />
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </div>
      </header>

      <main className="mx-auto w-full max-w-7xl px-4 py-6 lg:px-6">{children}</main>
    </div>
  );
}
