import type { Question } from "@/types/quiz";
import { getChapters } from "@/lib/filters";

export function ChapterFilter({
  questions,
  value,
  onChange,
  label = "Chương",
}: {
  questions: Question[];
  value: string;
  onChange: (value: string) => void;
  label?: string;
}) {
  return (
    <label className="grid gap-2 text-sm font-medium text-slate-700 dark:text-slate-200">
      {label}
      <select
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="h-11 rounded-md border border-slate-300 bg-white px-3 text-sm text-slate-950 shadow-sm outline-none transition focus:border-teal-600 focus:ring-2 focus:ring-teal-600/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
      >
        <option value="all">Tất cả chương</option>
        {getChapters(questions).map((chapter) => (
          <option key={chapter.id} value={chapter.id}>
            {chapter.id}: {chapter.title}
          </option>
        ))}
      </select>
    </label>
  );
}
