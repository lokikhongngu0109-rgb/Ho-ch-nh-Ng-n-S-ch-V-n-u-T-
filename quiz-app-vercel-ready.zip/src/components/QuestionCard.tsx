"use client";

import { AlertTriangle, CheckCircle2, Flag, Info } from "lucide-react";
import { useMemo } from "react";
import { AnswerOption } from "@/components/AnswerOption";
import { sectionLabels } from "@/lib/labels";
import { answerState, orderedChoices } from "@/lib/quiz";
import type { ChoiceKey, Question } from "@/types/quiz";

export function QuestionCard({
  question,
  selectedAnswer,
  reveal,
  shuffleAnswers,
  disabled,
  marked,
  onSelect,
}: {
  question: Question;
  selectedAnswer?: ChoiceKey;
  reveal: boolean;
  shuffleAnswers?: boolean;
  disabled?: boolean;
  marked?: boolean;
  onSelect: (answer: ChoiceKey) => void;
}) {
  const choices = useMemo(
    () => orderedChoices(question, shuffleAnswers),
    [question, shuffleAnswers],
  );
  const isCorrect = selectedAnswer === question.correctAnswer;

  return (
    <article className="rounded-lg border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
      <div className="border-b border-slate-100 p-4 dark:border-slate-800 sm:p-5">
        <div className="flex flex-wrap items-center gap-2 text-xs font-medium">
          <span className="rounded-md bg-slate-100 px-2 py-1 text-slate-700 dark:bg-slate-800 dark:text-slate-200">
            {question.sourceId}
          </span>
          <span className="rounded-md bg-teal-50 px-2 py-1 text-teal-800 dark:bg-teal-950 dark:text-teal-200">
            {question.chapter}
          </span>
          <span className="rounded-md bg-amber-50 px-2 py-1 text-amber-800 dark:bg-amber-950 dark:text-amber-200">
            {sectionLabels[question.section]}
          </span>
          {marked ? (
            <span className="inline-flex items-center gap-1 rounded-md bg-rose-50 px-2 py-1 text-rose-800 dark:bg-rose-950 dark:text-rose-200">
              <Flag aria-hidden size={13} /> Cần ôn
            </span>
          ) : null}
        </div>
        <h2 className="mt-4 text-lg font-semibold leading-8 text-slate-950 dark:text-white sm:text-xl">
          {question.question}
        </h2>
      </div>

      <div className="grid gap-3 p-4 sm:p-5">
        {choices.map((choice) => (
          <AnswerOption
            key={choice.key}
            choiceKey={choice.key}
            text={choice.text}
            state={answerState(choice.key, question.correctAnswer, selectedAnswer, reveal)}
            disabled={disabled || reveal}
            onSelect={() => onSelect(choice.key)}
          />
        ))}
      </div>

      {reveal ? (
        <div className="grid gap-3 border-t border-slate-100 p-4 dark:border-slate-800 sm:p-5">
          <div className="flex items-center gap-2 text-sm font-semibold">
            {isCorrect ? (
              <>
                <CheckCircle2 className="text-teal-600" aria-hidden size={18} />
                <span className="text-teal-700 dark:text-teal-300">Đúng</span>
              </>
            ) : (
              <>
                <AlertTriangle className="text-rose-600" aria-hidden size={18} />
                <span className="text-rose-700 dark:text-rose-300">
                  Sai · Đáp án đúng: {question.correctAnswer}
                </span>
              </>
            )}
          </div>
          <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm leading-6 text-slate-700 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200">
            <div className="flex items-start gap-2">
              <Info className="mt-1 shrink-0 text-slate-500" aria-hidden size={16} />
              <p>
                {question.explanation ??
                  "Chưa có giải thích trong dữ liệu gốc. Hãy đối chiếu đáp án với phần đáp án cuối tài liệu mẫu."}
              </p>
            </div>
          </div>
          {question.trapNote ? (
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm leading-6 text-amber-950 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-50">
              <strong>Ghi chú bẫy: </strong>
              {question.trapNote}
            </div>
          ) : null}
        </div>
      ) : null}
    </article>
  );
}
