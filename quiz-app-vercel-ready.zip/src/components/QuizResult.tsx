import Link from "next/link";
import type { ScoreItem } from "@/types/quiz";

export function QuizResult({
  total,
  correct,
  percent,
  items,
}: {
  total: number;
  correct: number;
  percent: number;
  items: ScoreItem[];
}) {
  return (
    <section className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-sm font-medium uppercase tracking-[0.14em] text-teal-700 dark:text-teal-300">
            Kết quả
          </p>
          <h2 className="mt-2 text-3xl font-semibold text-slate-950 dark:text-white">
            {correct}/{total} câu đúng
          </h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">Tỷ lệ đúng {percent}%</p>
        </div>
        <Link
          href="/review"
          className="inline-flex h-11 items-center justify-center rounded-md bg-teal-600 px-4 text-sm font-semibold text-white transition hover:bg-teal-700"
        >
          Ôn lại câu sai
        </Link>
      </div>

      <div className="mt-5 grid gap-2">
        {items.map((item, index) => (
          <div
            key={item.question.id}
            className="flex items-center justify-between gap-3 rounded-md border border-slate-200 p-3 text-sm dark:border-slate-800"
          >
            <div className="min-w-0">
              <span className="font-medium text-slate-900 dark:text-white">
                {index + 1}. {item.question.sourceId}
              </span>{" "}
              <span className="text-slate-600 dark:text-slate-300">{item.question.chapterTitle}</span>
            </div>
            <span
              className={
                item.isCorrect
                  ? "rounded-md bg-teal-50 px-2 py-1 font-semibold text-teal-700 dark:bg-teal-950 dark:text-teal-200"
                  : "rounded-md bg-rose-50 px-2 py-1 font-semibold text-rose-700 dark:bg-rose-950 dark:text-rose-200"
              }
            >
              {item.isCorrect ? "Đúng" : `Sai · ${item.question.correctAnswer}`}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}
