import type { ProgressState, Question } from "@/types/quiz";
import { chapterStats } from "@/lib/scoring";

export function ProgressSummary({
  questions,
  progress,
  compact = false,
}: {
  questions: Question[];
  progress: ProgressState;
  compact?: boolean;
}) {
  const stats = chapterStats(questions, progress);

  return (
    <section className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold text-slate-950 dark:text-white">Tiến độ theo chương</h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">
            Tính theo số câu đã từng làm và độ chính xác trên mọi lượt trả lời.
          </p>
        </div>
      </div>

      <div className="mt-4 grid gap-3">
        {stats.map((item) => (
          <div key={item.chapter} className="grid gap-2">
            <div className="flex items-center justify-between gap-3 text-sm">
              <div className="min-w-0">
                <span className="font-semibold text-slate-900 dark:text-white">{item.chapter}</span>
                <span className="ml-1 text-slate-600 dark:text-slate-300">{item.chapterTitle}</span>
              </div>
              <span className="shrink-0 font-medium text-slate-700 dark:text-slate-200">
                {item.attemptedQuestions}/{item.total} · {item.accuracy}%
              </span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
              <div
                className="h-full rounded-full bg-teal-600"
                style={{ width: `${item.completion}%` }}
              />
            </div>
            {!compact && item.wrongQuestions > 0 ? (
              <p className="text-xs text-rose-700 dark:text-rose-300">
                {item.wrongQuestions} câu đang cần ôn lại
              </p>
            ) : null}
          </div>
        ))}
      </div>
    </section>
  );
}
