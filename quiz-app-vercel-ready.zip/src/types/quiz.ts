export type ChoiceKey = "A" | "B" | "C" | "D" | "E";

export type QuestionSection = "must_know" | "easy_to_miss" | "supplement";

export type Difficulty = "basic" | "medium" | "hard";

export type Question = {
  id: string;
  sourceId: string;
  chapter: string;
  chapterTitle: string;
  section: QuestionSection;
  topic?: string | null;
  question: string;
  choices: {
    key: ChoiceKey;
    text: string;
  }[];
  correctAnswer: ChoiceKey;
  explanation?: string;
  trapNote?: string;
  difficulty?: Difficulty;
};

export type QuestionAttempt = {
  selectedAnswer?: ChoiceKey;
  correctAnswer: ChoiceKey;
  isCorrect: boolean;
  mode: "practice" | "exam";
  answeredAt: string;
};

export type QuestionProgress = {
  attempts: number;
  correct: number;
  wrong: number;
  correctStreak: number;
  needsReview: boolean;
  marked: boolean;
  lastAnsweredAt?: string;
  lastSelectedAnswer?: ChoiceKey;
  history: QuestionAttempt[];
};

export type ProgressState = {
  version: 1;
  questions: Record<string, QuestionProgress>;
  exams: ExamSessionSummary[];
  streak: {
    count: number;
    lastStudyDate?: string;
  };
};

export type ExamSessionSummary = {
  id: string;
  submittedAt: string;
  total: number;
  correct: number;
  percent: number;
  durationSeconds: number;
};

export type QuestionFilters = {
  chapter?: string;
  section?: QuestionSection | "all";
  search?: string;
  onlyUnseen?: boolean;
  onlyWrong?: boolean;
  minWrong?: number;
};

export type StudyConfig = QuestionFilters & {
  amount?: number;
  shuffleQuestions?: boolean;
  shuffleAnswers?: boolean;
};

export type ScoreItem = {
  question: Question;
  selectedAnswer?: ChoiceKey;
  isCorrect: boolean;
};
