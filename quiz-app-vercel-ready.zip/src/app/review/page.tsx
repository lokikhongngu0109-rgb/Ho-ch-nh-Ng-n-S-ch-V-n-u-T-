"use client";

import { RotateCcw, SearchX, Trash2 } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { ChapterFilter } from "@/components/ChapterFilter";
import { EmptyState } from "@/components/EmptyState";
import { QuestionCard } from "@/components/QuestionCard";
import { questions } from "@/data/questions";
import { filterQuestions } from "@/lib/filters";
import { useProgress } from "@/lib/use-progress";

export default function ReviewPage() {
  const { progress, ready, clearWrong } = useProgress();
  const [chapter, setChapter] = useState("all");
  const [minWrong, setMinWrong] = useState(1);
  const [openId, setOpenId] = useState<string | null>(null);
  const wrongQuestions = filterQuestions(questions, { chapter, onlyWrong: true, minWrong }, progress);
  const openQuestion = wrongQuestions.find((question) => question.id === openId);

  return (
    <div className="grid gap-6">
      <section className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.16em] text-teal-700 dark:text-teal-300">
              Câu sai cần ôn lại
            </p>
            <h2 className="mt-2 text-2xl font-semibold text-slate-950 dark:text-white">Luyện lại điểm yếu</h2>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600 dark:text-slate-300">
              Câu sai tự được đưa vào đây sau luyện tập hoặc thi thử. Khi bạn làm đúng liên tiếp 2 lần, câu đó tự rời
              khỏi danh sách cần ôn.
            </p>
          </div>
          <Link
            href={`/practice?onlyWrong=1${chapter !== "all" ? `&chapter=${chapter}` : ""}`}
            className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-teal-600 px-4 text-sm font-semibold text-white transition hover:bg-teal-700"
          >
            <RotateCcw aria-hidden size={16} />
            Làm lại toàn bộ câu sai
          </Link>
        </div>

        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          <ChapterFilter questions={questions} value={chapter} onChange={setChapter} />
          <label className="grid gap-2 text-sm font-medium text-slate-700 dark:text-slate-200">
            Số lần sai tối thiểu
            <input
              type="number"
              min={1}
              value={minWrong}
              onChange={(event) => setMinWrong(Number(event.target.value))}
              className="h-11 rounded-md border border-slate-300 bg-white px-3 text-sm text-slate-950 shadow-sm outline-none transition focus:border-teal-600 focus:ring-2 focus:ring-teal-600/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </label>
        </div>
      </section>

      {!ready ? (
        <section className="rounded-lg border border-slate-200 bg-white p-5 text-sm text-slate-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300">
          Đang tải tiến độ...
        </section>
      ) : wrongQuestions.length === 0 ? (
        <EmptyState
          icon={SearchX}
          title="Chưa có câu sai phù hợp"
          description="Hãy làm một phiên luyện tập hoặc thi thử, hoặc giảm điều kiện lọc số lần sai."
        />
      ) : (
        <section className="grid gap-3">
          {wrongQuestions.map((question) => {
            const record = progress.questions[question.id];
            return (
              <article
                key={question.id}
                className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900"
              >
                <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
                  <button type="button" onClick={() => setOpenId(openId === question.id ? null : question.id)} className="min-w-0 text-left">
                    <p className="text-sm font-semibold text-slate-950 dark:text-white">
                      {question.sourceId} · {question.chapterTitle}
                    </p>
                    <p className="mt-1 line-clamp-2 text-sm leading-6 text-slate-600 dark:text-slate-300">
                      {question.question}
                    </p>
                  </button>
                  <div className="flex shrink-0 flex-wrap gap-2">
                    <span className="rounded-md bg-rose-50 px-2 py-1 text-sm font-semibold text-rose-800 dark:bg-rose-950 dark:text-rose-100">
                      Sai {record?.wrong ?? 0} lần
                    </span>
                    <span className="rounded-md bg-slate-100 px-2 py-1 text-sm font-semibold text-slate-700 dark:bg-slate-800 dark:text-slate-200">
                      Đúng liên tiếp {record?.correctStreak ?? 0}
                    </span>
                    <button
                      type="button"
                      onClick={() => clearWrong(question.id)}
                      className="inline-flex items-center gap-1 rounded-md border border-slate-300 px-2 py-1 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                    >
                      <Trash2 aria-hidden size={14} />
                      Xóa khỏi danh sách
                    </button>
                  </div>
                </div>
                {openQuestion?.id === question.id ? (
                  <div className="mt-4">
                    <QuestionCard
                      question={question}
                      selectedAnswer={record?.lastSelectedAnswer}
                      reveal
                      disabled
                      onSelect={() => undefined}
                    />
                  </div>
                ) : null}
              </article>
            );
          })}
        </section>
      )}
    </div>
  );
}
