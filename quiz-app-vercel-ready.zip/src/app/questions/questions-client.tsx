"use client";

import { Eye, EyeOff, Search } from "lucide-react";
import { useSearchParams } from "next/navigation";
import { useState } from "react";
import { ChapterFilter } from "@/components/ChapterFilter";
import { QuestionCard } from "@/components/QuestionCard";
import { questions } from "@/data/questions";
import { filterQuestions, isWrongQuestion } from "@/lib/filters";
import { sectionLabels } from "@/lib/labels";
import { useProgress } from "@/lib/use-progress";
import type { QuestionSection } from "@/types/quiz";

export function QuestionsClient() {
  const searchParams = useSearchParams();
  const { progress } = useProgress();
  const [search, setSearch] = useState(searchParams.get("search") ?? "");
  const [chapter, setChapter] = useState("all");
  const [section, setSection] = useState<QuestionSection | "all">("all");
  const [showAnswers, setShowAnswers] = useState(true);
  const [openId, setOpenId] = useState<string | null>(searchParams.get("search") ? null : questions[0]?.id);
  const filtered = filterQuestions(questions, { search, chapter, section }, progress);

  return (
    <div className="grid gap-6">
      <section className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.16em] text-teal-700 dark:text-teal-300">
            Ngân hàng câu hỏi
          </p>
          <h2 className="mt-2 text-2xl font-semibold text-slate-950 dark:text-white">
            Tra cứu toàn bộ câu hỏi và đáp án
          </h2>
        </div>

        <div className="mt-5 grid gap-4 lg:grid-cols-[1.2fr_1fr_1fr_auto]">
          <label className="grid gap-2 text-sm font-medium text-slate-700 dark:text-slate-200">
            Search nội dung
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-3 text-slate-400" aria-hidden size={16} />
              <input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="APR, WACC, C13.7..."
                className="h-11 w-full rounded-md border border-slate-300 bg-white pl-9 pr-3 text-sm text-slate-950 shadow-sm outline-none transition focus:border-teal-600 focus:ring-2 focus:ring-teal-600/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>
          </label>
          <ChapterFilter questions={questions} value={chapter} onChange={setChapter} />
          <label className="grid gap-2 text-sm font-medium text-slate-700 dark:text-slate-200">
            Nhóm
            <select
              value={section}
              onChange={(event) => setSection(event.target.value as QuestionSection | "all")}
              className="h-11 rounded-md border border-slate-300 bg-white px-3 text-sm text-slate-950 shadow-sm outline-none transition focus:border-teal-600 focus:ring-2 focus:ring-teal-600/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            >
              <option value="all">Tất cả nhóm</option>
              {Object.entries(sectionLabels).map(([key, label]) => (
                <option key={key} value={key}>
                  {label}
                </option>
              ))}
            </select>
          </label>
          <button
            type="button"
            onClick={() => setShowAnswers((value) => !value)}
            className="mt-auto inline-flex h-11 items-center justify-center gap-2 rounded-md border border-slate-300 bg-white px-4 text-sm font-semibold text-slate-800 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
          >
            {showAnswers ? <EyeOff aria-hidden size={16} /> : <Eye aria-hidden size={16} />}
            {showAnswers ? "Ẩn đáp án" : "Hiện đáp án"}
          </button>
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-[0.85fr_1.15fr]">
        <div className="grid max-h-[72vh] gap-2 overflow-auto pr-1">
          <p className="text-sm text-slate-600 dark:text-slate-300">{filtered.length} câu phù hợp</p>
          {filtered.map((question) => {
            const record = progress.questions[question.id];
            return (
              <button
                key={question.id}
                type="button"
                onClick={() => setOpenId(question.id)}
                className={
                  openId === question.id
                    ? "rounded-lg border border-teal-500 bg-teal-50 p-4 text-left shadow-sm dark:bg-teal-950/40"
                    : "rounded-lg border border-slate-200 bg-white p-4 text-left shadow-sm transition hover:border-teal-300 hover:bg-teal-50 dark:border-slate-800 dark:bg-slate-900 dark:hover:border-teal-800 dark:hover:bg-teal-950/30"
                }
              >
                <div className="flex flex-wrap items-center gap-2 text-xs font-semibold">
                  <span className="rounded-md bg-slate-100 px-2 py-1 text-slate-700 dark:bg-slate-800 dark:text-slate-200">
                    {question.sourceId}
                  </span>
                  <span className="rounded-md bg-teal-100 px-2 py-1 text-teal-800 dark:bg-teal-950 dark:text-teal-100">
                    {question.chapter}
                  </span>
                  {isWrongQuestion(record) ? (
                    <span className="rounded-md bg-rose-50 px-2 py-1 text-rose-800 dark:bg-rose-950 dark:text-rose-100">
                      Câu sai
                    </span>
                  ) : record?.attempts ? (
                    <span className="rounded-md bg-slate-100 px-2 py-1 text-slate-700 dark:bg-slate-800 dark:text-slate-200">
                      Đã làm
                    </span>
                  ) : null}
                </div>
                <p className="mt-3 line-clamp-3 text-sm leading-6 text-slate-700 dark:text-slate-200">
                  {question.question}
                </p>
                {showAnswers ? (
                  <p className="mt-2 text-sm font-semibold text-teal-700 dark:text-teal-300">
                    Đáp án: {question.correctAnswer}
                  </p>
                ) : null}
              </button>
            );
          })}
        </div>

        <div className="lg:sticky lg:top-32 lg:self-start">
          {filtered.find((question) => question.id === openId) ? (
            <QuestionCard
              question={filtered.find((question) => question.id === openId)!}
              selectedAnswer={showAnswers ? filtered.find((question) => question.id === openId)!.correctAnswer : undefined}
              reveal={showAnswers}
              disabled
              onSelect={() => undefined}
            />
          ) : (
            <section className="rounded-lg border border-dashed border-slate-300 bg-white p-8 text-center text-sm text-slate-600 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300">
              Chọn một câu để xem chi tiết.
            </section>
          )}
        </div>
      </section>
    </div>
  );
}
