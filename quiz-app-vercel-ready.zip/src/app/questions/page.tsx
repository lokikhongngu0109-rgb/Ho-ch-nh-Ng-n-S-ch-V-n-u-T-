import { Suspense } from "react";
import { QuestionsClient } from "@/app/questions/questions-client";

export default function QuestionsPage() {
  return (
    <Suspense fallback={<div className="rounded-lg border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">Đang tải...</div>}>
      <QuestionsClient />
    </Suspense>
  );
}
