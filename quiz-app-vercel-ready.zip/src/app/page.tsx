"use client";

import {
  BarChart3,
  BookOpenCheck,
  ClipboardList,
  Database,
  Flame,
  RotateCcw,
  Target,
} from "lucide-react";
import Link from "next/link";
import { MetricCard } from "@/components/MetricCard";
import { ProgressSummary } from "@/components/ProgressSummary";
import { questions, QUESTION_BANK_SOURCE } from "@/data/questions";
import { useProgress } from "@/lib/use-progress";
import { mostMissedQuestions, summarizeProgress, weakestChapters } from "@/lib/scoring";

const quickActions = [
  { href: "/practice?mode=all", label: "Ôn toàn bộ", icon: BookOpenCheck },
  { href: "/practice?section=must_know", label: "Ôn câu bắt buộc", icon: Target },
  { href: "/practice?section=easy_to_miss", label: "Ôn câu dễ bỏ sót", icon: Flame },
  { href: "/exam", label: "Làm đề thi thử", icon: ClipboardList },
  { href: "/practice?onlyWrong=1", label: "Ôn câu sai", icon: RotateCcw },
];

export default function DashboardPage() {
  const { progress, ready } = useProgress();
  const summary = summarizeProgress(questions, progress);
  const weak = weakestChapters(questions, progress);
  const missed = mostMissedQuestions(questions, progress, 5);

  return (
    <div className="grid gap-6">
      <section className="grid gap-4 rounded-lg border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.16em] text-teal-700 dark:text-teal-300">
              Dashboard học tập
            </p>
            <h2 className="mt-2 text-2xl font-semibold leading-tight text-slate-950 dark:text-white sm:text-3xl">
              Ôn trắc nghiệm theo chương, theo nhóm câu và theo lỗi sai
            </h2>
            <p className="mt-3 max-w-3xl text-sm leading-6 text-slate-600 dark:text-slate-300">
              Dữ liệu lấy từ {QUESTION_BANK_SOURCE.sourceFile}, gồm {QUESTION_BANK_SOURCE.totalQuestions} câu và đáp án
              khớp phần {QUESTION_BANK_SOURCE.answerSource}.
            </p>
          </div>
          {!ready ? (
            <span className="rounded-md bg-slate-100 px-3 py-2 text-sm text-slate-600 dark:bg-slate-800 dark:text-slate-300">
              Đang tải tiến độ...
            </span>
          ) : null}
        </div>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <Link
                key={action.href}
                href={action.href}
                className="inline-flex h-12 items-center justify-center gap-2 rounded-md bg-slate-950 px-3 text-sm font-semibold text-white transition hover:bg-slate-800 dark:bg-white dark:text-slate-950 dark:hover:bg-slate-200"
              >
                <Icon aria-hidden size={17} />
                {action.label}
              </Link>
            );
          })}
        </div>
      </section>

      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <MetricCard
          label="Tổng số câu"
          value={summary.totalQuestions}
          detail="Toàn bộ ngân hàng câu hỏi"
          icon={<Database aria-hidden size={20} />}
          tone="slate"
        />
        <MetricCard
          label="Đã làm"
          value={summary.attempted}
          detail={`${Math.round((summary.attempted / summary.totalQuestions) * 100)}% ngân hàng`}
          icon={<BookOpenCheck aria-hidden size={20} />}
          tone="teal"
        />
        <MetricCard
          label="Tỷ lệ đúng"
          value={`${summary.accuracy}%`}
          detail={`${summary.totalAttempts} lượt trả lời`}
          icon={<BarChart3 aria-hidden size={20} />}
          tone="slate"
        />
        <MetricCard
          label="Câu sai cần ôn"
          value={summary.wrongQuestions}
          detail="Tự giảm sau 2 lần đúng liên tiếp"
          icon={<RotateCcw aria-hidden size={20} />}
          tone="rose"
        />
        <MetricCard
          label="Streak"
          value={summary.streak}
          detail="Ngày học liên tiếp"
          icon={<Flame aria-hidden size={20} />}
          tone="amber"
        />
      </section>

      <section className="grid gap-6 lg:grid-cols-[1.4fr_0.8fr]">
        <ProgressSummary questions={questions} progress={progress} />

        <div className="grid gap-6">
          <section className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <h2 className="text-lg font-semibold text-slate-950 dark:text-white">Chương nên ưu tiên</h2>
            <div className="mt-4 grid gap-3">
              {weak.length ? (
                weak.map((item) => (
                  <Link
                    key={item.chapter}
                    href={`/practice?chapter=${item.chapter}`}
                    className="rounded-md border border-slate-200 p-3 text-sm transition hover:border-teal-300 hover:bg-teal-50 dark:border-slate-800 dark:hover:border-teal-800 dark:hover:bg-teal-950/30"
                  >
                    <span className="font-semibold text-slate-950 dark:text-white">{item.chapter}</span>{" "}
                    <span className="text-slate-600 dark:text-slate-300">{item.chapterTitle}</span>
                    <span className="mt-2 block text-rose-700 dark:text-rose-300">
                      Accuracy {item.accuracy}% · {item.wrongQuestions} câu sai
                    </span>
                  </Link>
                ))
              ) : (
                <p className="text-sm leading-6 text-slate-600 dark:text-slate-300">
                  Chưa đủ dữ liệu. Hãy làm một phiên luyện tập hoặc thi thử để app gợi ý chương yếu.
                </p>
              )}
            </div>
          </section>

          <section className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <h2 className="text-lg font-semibold text-slate-950 dark:text-white">Câu hay sai</h2>
            <div className="mt-4 grid gap-2">
              {missed.length ? (
                missed.map((item) => (
                  <Link
                    key={item.question.id}
                    href={`/questions?search=${encodeURIComponent(item.question.sourceId)}`}
                    className="flex items-center justify-between gap-3 rounded-md border border-slate-200 p-3 text-sm dark:border-slate-800"
                  >
                    <span className="font-medium text-slate-900 dark:text-white">{item.question.sourceId}</span>
                    <span className="text-rose-700 dark:text-rose-300">{item.wrong} lần sai</span>
                  </Link>
                ))
              ) : (
                <p className="text-sm leading-6 text-slate-600 dark:text-slate-300">
                  Chưa có câu sai nào được ghi nhận.
                </p>
              )}
            </div>
          </section>
        </div>
      </section>
    </div>
  );
}
