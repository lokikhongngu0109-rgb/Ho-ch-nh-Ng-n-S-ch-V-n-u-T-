"use client";

import { AlertTriangle, ArrowLeft, ArrowRight, CheckCircle2, ClipboardCheck, Play } from "lucide-react";
import { useCallback, useMemo, useState } from "react";
import { ChapterFilter } from "@/components/ChapterFilter";
import { QuestionCard } from "@/components/QuestionCard";
import { QuizResult } from "@/components/QuizResult";
import { Timer } from "@/components/Timer";
import { questions } from "@/data/questions";
import { filterQuestions } from "@/lib/filters";
import { sectionLabels } from "@/lib/labels";
import { buildStudyQueue, shouldRevealAnswer } from "@/lib/quiz";
import { scoreAnswers } from "@/lib/scoring";
import { useProgress } from "@/lib/use-progress";
import type { ChoiceKey, Question, QuestionSection } from "@/types/quiz";

export function ExamClient() {
  const { progress, ready, recordAnswer, storeExam } = useProgress();
  const [chapter, setChapter] = useState("all");
  const [section, setSection] = useState<QuestionSection | "all">("all");
  const [amount, setAmount] = useState(30);
  const [minutes, setMinutes] = useState(45);
  const [shuffleAnswers, setShuffleAnswers] = useState(true);
  const [session, setSession] = useState<Question[] | null>(null);
  const [answers, setAnswers] = useState<Record<string, ChoiceKey | undefined>>({});
  const [currentIndex, setCurrentIndex] = useState(0);
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [confirming, setConfirming] = useState(false);

  const config = useMemo(
    () => ({ chapter, section, amount, shuffleQuestions: true, shuffleAnswers }),
    [amount, chapter, section, shuffleAnswers],
  );
  const available = filterQuestions(questions, config, progress).length;
  const durationSeconds = minutes * 60;

  function startExam() {
    const queue = buildStudyQueue(questions, config, progress);
    setSession(queue);
    setAnswers({});
    setCurrentIndex(0);
    setStartedAt(Date.now());
    setSubmitted(false);
    setConfirming(false);
  }

  const submitExam = useCallback(() => {
    if (!session || submitted) {
      return;
    }

    const result = scoreAnswers(session, answers);
    const elapsed = startedAt ? Math.max(1, Math.round((Date.now() - startedAt) / 1000)) : durationSeconds;

    for (const question of session) {
      recordAnswer(question, answers[question.id], "exam");
    }

    storeExam({
      id: `exam-${Date.now()}`,
      submittedAt: new Date().toISOString(),
      total: result.total,
      correct: result.correct,
      percent: result.percent,
      durationSeconds: elapsed,
    });

    setSubmitted(true);
    setConfirming(false);
  }, [answers, durationSeconds, recordAnswer, session, startedAt, storeExam, submitted]);

  if (!session) {
    return (
      <section className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.16em] text-teal-700 dark:text-teal-300">
            Thi thử
          </p>
          <h2 className="mt-2 text-2xl font-semibold text-slate-950 dark:text-white">
            Mô phỏng kỳ thi không hiện đáp án trong lúc làm
          </h2>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600 dark:text-slate-300">
            Chọn số câu và thời gian. App chỉ chấm điểm, hiện đáp án và ghi nhận câu sai sau khi bạn nộp bài.
          </p>
        </div>

        <div className="mt-5 grid gap-4 lg:grid-cols-4">
          <ChapterFilter questions={questions} value={chapter} onChange={setChapter} />
          <label className="grid gap-2 text-sm font-medium text-slate-700 dark:text-slate-200">
            Nhóm câu
            <select
              value={section}
              onChange={(event) => setSection(event.target.value as QuestionSection | "all")}
              className="h-11 rounded-md border border-slate-300 bg-white px-3 text-sm text-slate-950 shadow-sm outline-none transition focus:border-teal-600 focus:ring-2 focus:ring-teal-600/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            >
              <option value="all">Tất cả nhóm</option>
              {Object.entries(sectionLabels).map(([key, label]) => (
                <option key={key} value={key}>
                  {label}
                </option>
              ))}
            </select>
          </label>
          <label className="grid gap-2 text-sm font-medium text-slate-700 dark:text-slate-200">
            Số câu
            <input
              type="number"
              min={1}
              max={questions.length}
              value={amount}
              onChange={(event) => setAmount(Number(event.target.value))}
              className="h-11 rounded-md border border-slate-300 bg-white px-3 text-sm text-slate-950 shadow-sm outline-none transition focus:border-teal-600 focus:ring-2 focus:ring-teal-600/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </label>
          <label className="grid gap-2 text-sm font-medium text-slate-700 dark:text-slate-200">
            Thời gian (phút)
            <input
              type="number"
              min={1}
              value={minutes}
              onChange={(event) => setMinutes(Number(event.target.value))}
              className="h-11 rounded-md border border-slate-300 bg-white px-3 text-sm text-slate-950 shadow-sm outline-none transition focus:border-teal-600 focus:ring-2 focus:ring-teal-600/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </label>
        </div>

        <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <label className="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700 dark:text-slate-200">
            <input
              type="checkbox"
              checked={shuffleAnswers}
              onChange={(event) => setShuffleAnswers(event.target.checked)}
              className="h-5 w-5 accent-teal-600"
            />
            Trộn đáp án
          </label>
          <div className="flex items-center gap-3">
            <p className="text-sm text-slate-600 dark:text-slate-300">
              {ready ? `${available} câu có thể ra đề` : "Đang tải tiến độ..."}
            </p>
            <button
              type="button"
              disabled={!ready || available === 0}
              onClick={startExam}
              className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-teal-600 px-4 text-sm font-semibold text-white transition hover:bg-teal-700 disabled:cursor-not-allowed disabled:bg-slate-400"
            >
              <Play aria-hidden size={16} />
              Bắt đầu thi
            </button>
          </div>
        </div>
      </section>
    );
  }

  if (!session.length) {
    return (
      <section className="rounded-lg border border-slate-200 bg-white p-5 text-sm text-slate-700 shadow-sm dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200">
        Không có câu phù hợp để tạo đề thi. Hãy quay lại và đổi bộ lọc.
      </section>
    );
  }

  const result = scoreAnswers(session, answers);
  const current = session[currentIndex];
  const reveal = shouldRevealAnswer("exam", submitted);
  const weakChapters = getWeakChapterHints(result.items);

  if (submitted) {
    return (
      <div className="grid gap-5">
        <QuizResult total={result.total} correct={result.correct} percent={result.percent} items={result.items} />

        <section className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <h2 className="text-lg font-semibold text-slate-950 dark:text-white">Gợi ý chương cần ôn lại</h2>
          <div className="mt-3 flex flex-wrap gap-2">
            {weakChapters.length ? (
              weakChapters.map((item) => (
                <span
                  key={item.chapter}
                  className="rounded-md bg-rose-50 px-3 py-2 text-sm font-medium text-rose-800 dark:bg-rose-950 dark:text-rose-100"
                >
                  {item.chapter}: {item.wrong} câu sai
                </span>
              ))
            ) : (
              <span className="rounded-md bg-teal-50 px-3 py-2 text-sm font-medium text-teal-800 dark:bg-teal-950 dark:text-teal-100">
                Không có câu sai trong đề này
              </span>
            )}
          </div>
        </section>

        <section className="grid gap-4">
          <h2 className="text-lg font-semibold text-slate-950 dark:text-white">Xem lại từng câu</h2>
          {session.map((question) => (
            <QuestionCard
              key={question.id}
              question={question}
              selectedAnswer={answers[question.id]}
              reveal={reveal}
              shuffleAnswers={false}
              disabled
              onSelect={() => undefined}
            />
          ))}
        </section>
      </div>
    );
  }

  if (confirming) {
    return (
      <section className="mx-auto max-w-2xl rounded-lg border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-start gap-3">
          <AlertTriangle className="mt-1 text-amber-600" aria-hidden size={22} />
          <div>
            <h2 className="text-xl font-semibold text-slate-950 dark:text-white">Nộp bài thi thử?</h2>
            <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">
              Bạn đã trả lời {Object.keys(answers).length}/{session.length} câu. Sau khi nộp, app sẽ chấm điểm, hiện
              đáp án và lưu câu sai vào tiến độ học.
            </p>
          </div>
        </div>
        <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-end">
          <button
            type="button"
            onClick={() => setConfirming(false)}
            className="inline-flex h-11 items-center justify-center gap-2 rounded-md border border-slate-300 bg-white px-4 text-sm font-semibold text-slate-800 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
          >
            <ArrowLeft aria-hidden size={16} />
            Quay lại làm bài
          </button>
          <button
            type="button"
            onClick={submitExam}
            className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-teal-600 px-4 text-sm font-semibold text-white transition hover:bg-teal-700"
          >
            <ClipboardCheck aria-hidden size={16} />
            Nộp bài
          </button>
        </div>
      </section>
    );
  }

  return (
    <div className="grid gap-5">
      <section className="flex flex-col gap-3 rounded-lg border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <p className="text-sm font-medium text-slate-600 dark:text-slate-300">
            Câu {currentIndex + 1}/{session.length} · Đã trả lời {Object.keys(answers).length}/{session.length}
          </p>
          <div className="mt-2 h-2 w-full min-w-64 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
            <div
              className="h-full rounded-full bg-teal-600"
              style={{ width: `${((currentIndex + 1) / session.length) * 100}%` }}
            />
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Timer durationSeconds={durationSeconds} running={!submitted} onExpire={submitExam} />
          <button
            type="button"
            onClick={() => setCurrentIndex((index) => Math.max(0, index - 1))}
            className="inline-flex h-10 items-center justify-center gap-2 rounded-md border border-slate-300 bg-white px-3 text-sm font-semibold text-slate-800 transition hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
            disabled={currentIndex === 0}
          >
            <ArrowLeft aria-hidden size={16} />
            Trước
          </button>
          <button
            type="button"
            onClick={() => setCurrentIndex((index) => Math.min(session.length - 1, index + 1))}
            className="inline-flex h-10 items-center justify-center gap-2 rounded-md border border-slate-300 bg-white px-3 text-sm font-semibold text-slate-800 transition hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
            disabled={currentIndex === session.length - 1}
          >
            Sau
            <ArrowRight aria-hidden size={16} />
          </button>
          <button
            type="button"
            onClick={() => setConfirming(true)}
            className="inline-flex h-10 items-center justify-center gap-2 rounded-md bg-teal-600 px-3 text-sm font-semibold text-white transition hover:bg-teal-700"
          >
            <CheckCircle2 aria-hidden size={16} />
            Nộp bài
          </button>
        </div>
      </section>

      <QuestionCard
        question={current}
        selectedAnswer={answers[current.id]}
        reveal={reveal}
        shuffleAnswers={shuffleAnswers}
        onSelect={(answer) => setAnswers((value) => ({ ...value, [current.id]: answer }))}
      />

      <section className="flex flex-wrap gap-2">
        {session.map((question, index) => (
          <button
            type="button"
            key={question.id}
            onClick={() => setCurrentIndex(index)}
            className={
              index === currentIndex
                ? "h-9 min-w-9 rounded-md bg-teal-600 px-2 text-sm font-semibold text-white"
                : answers[question.id]
                  ? "h-9 min-w-9 rounded-md border border-teal-300 bg-teal-50 px-2 text-sm font-semibold text-teal-800 dark:border-teal-800 dark:bg-teal-950 dark:text-teal-100"
                  : "h-9 min-w-9 rounded-md border border-slate-300 bg-white px-2 text-sm font-semibold text-slate-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
            }
          >
            {index + 1}
          </button>
        ))}
      </section>
    </div>
  );
}

function getWeakChapterHints(items: ReturnType<typeof scoreAnswers>["items"]) {
  const counts = new Map<string, number>();
  for (const item of items) {
    if (!item.isCorrect) {
      counts.set(item.question.chapter, (counts.get(item.question.chapter) ?? 0) + 1);
    }
  }
  return Array.from(counts, ([chapter, wrong]) => ({ chapter, wrong })).sort((a, b) => b.wrong - a.wrong);
}
