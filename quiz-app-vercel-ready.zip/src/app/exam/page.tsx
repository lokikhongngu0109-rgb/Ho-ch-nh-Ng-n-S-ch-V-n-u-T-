import { ExamClient } from "@/app/exam/exam-client";

export default function ExamPage() {
  return <ExamClient />;
}
