"use client";

import { BarChart3, Flame, RotateCcw, TrendingDown } from "lucide-react";
import Link from "next/link";
import { MetricCard } from "@/components/MetricCard";
import { ProgressSummary } from "@/components/ProgressSummary";
import { questions } from "@/data/questions";
import { chapterStats, mostMissedQuestions, summarizeProgress, weakestChapters } from "@/lib/scoring";
import { useProgress } from "@/lib/use-progress";

export default function ProgressPage() {
  const { progress, reset } = useProgress();
  const summary = summarizeProgress(questions, progress);
  const chapters = chapterStats(questions, progress);
  const weak = weakestChapters(questions, progress, 5);
  const missed = mostMissedQuestions(questions, progress, 10);

  function resetProgress() {
    if (window.confirm("Xóa toàn bộ tiến độ học trên trình duyệt này?")) {
      reset();
    }
  }

  return (
    <div className="grid gap-6">
      <section className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.16em] text-teal-700 dark:text-teal-300">
              Tiến độ học
            </p>
            <h2 className="mt-2 text-2xl font-semibold text-slate-950 dark:text-white">
              Thống kê local-first trong trình duyệt
            </h2>
          </div>
          <button
            type="button"
            onClick={resetProgress}
            className="inline-flex h-11 items-center justify-center gap-2 rounded-md border border-rose-200 bg-rose-50 px-4 text-sm font-semibold text-rose-800 transition hover:bg-rose-100 dark:border-rose-800 dark:bg-rose-950/40 dark:text-rose-100"
          >
            <RotateCcw aria-hidden size={16} />
            Reset tiến độ
          </button>
        </div>
      </section>

      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <MetricCard label="Đã làm" value={`${summary.attempted}/${summary.totalQuestions}`} icon={<BarChart3 aria-hidden size={20} />} tone="teal" />
        <MetricCard label="Accuracy" value={`${summary.accuracy}%`} detail={`${summary.totalAttempts} lượt trả lời`} icon={<BarChart3 aria-hidden size={20} />} tone="slate" />
        <MetricCard label="Câu sai" value={summary.wrongQuestions} detail="Đang cần ôn lại" icon={<TrendingDown aria-hidden size={20} />} tone="rose" />
        <MetricCard label="Streak" value={summary.streak} detail="Ngày liên tiếp" icon={<Flame aria-hidden size={20} />} tone="amber" />
      </section>

      <section className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
        <ProgressSummary questions={questions} progress={progress} />
        <div className="grid gap-6">
          <section className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <h2 className="text-lg font-semibold text-slate-950 dark:text-white">Top chương yếu nhất</h2>
            <div className="mt-4 grid gap-3">
              {weak.length ? (
                weak.map((item) => (
                  <Link
                    key={item.chapter}
                    href={`/practice?chapter=${item.chapter}`}
                    className="rounded-md border border-slate-200 p-3 text-sm transition hover:border-teal-300 hover:bg-teal-50 dark:border-slate-800 dark:hover:border-teal-800 dark:hover:bg-teal-950/30"
                  >
                    <span className="font-semibold text-slate-950 dark:text-white">{item.chapter}</span>{" "}
                    <span className="text-slate-600 dark:text-slate-300">{item.chapterTitle}</span>
                    <span className="mt-1 block text-rose-700 dark:text-rose-300">
                      {item.accuracy}% accuracy · {item.wrongQuestions} câu sai
                    </span>
                  </Link>
                ))
              ) : (
                <p className="text-sm leading-6 text-slate-600 dark:text-slate-300">
                  Chưa có dữ liệu theo chương.
                </p>
              )}
            </div>
          </section>

          <section className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <h2 className="text-lg font-semibold text-slate-950 dark:text-white">Lịch sử đề thi thử</h2>
            <div className="mt-4 grid gap-2">
              {progress.exams.length ? (
                progress.exams.map((exam) => (
                  <div
                    key={exam.id}
                    className="flex items-center justify-between gap-3 rounded-md border border-slate-200 p-3 text-sm dark:border-slate-800"
                  >
                    <span className="text-slate-600 dark:text-slate-300">
                      {new Date(exam.submittedAt).toLocaleDateString("vi-VN")}
                    </span>
                    <span className="font-semibold text-slate-950 dark:text-white">
                      {exam.correct}/{exam.total} · {exam.percent}%
                    </span>
                  </div>
                ))
              ) : (
                <p className="text-sm leading-6 text-slate-600 dark:text-slate-300">
                  Chưa có bài thi thử nào được nộp.
                </p>
              )}
            </div>
          </section>
        </div>
      </section>

      <section className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <h2 className="text-lg font-semibold text-slate-950 dark:text-white">Danh sách câu hay sai</h2>
        <div className="mt-4 grid gap-2 md:grid-cols-2">
          {missed.length ? (
            missed.map((item) => (
              <Link
                key={item.question.id}
                href={`/questions?search=${encodeURIComponent(item.question.sourceId)}`}
                className="rounded-md border border-slate-200 p-3 text-sm transition hover:border-teal-300 hover:bg-teal-50 dark:border-slate-800 dark:hover:border-teal-800 dark:hover:bg-teal-950/30"
              >
                <span className="font-semibold text-slate-950 dark:text-white">{item.question.sourceId}</span>{" "}
                <span className="text-slate-600 dark:text-slate-300">{item.question.chapterTitle}</span>
                <span className="mt-1 block text-rose-700 dark:text-rose-300">{item.wrong} lần sai</span>
              </Link>
            ))
          ) : (
            <p className="text-sm leading-6 text-slate-600 dark:text-slate-300">
              Chưa có câu sai nào để thống kê.
            </p>
          )}
        </div>
      </section>

      <section className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <h2 className="text-lg font-semibold text-slate-950 dark:text-white">Accuracy theo chương</h2>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[680px] border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-600 dark:border-slate-800 dark:text-slate-300">
                <th className="py-3 pr-3">Chương</th>
                <th className="py-3 pr-3">Đã làm</th>
                <th className="py-3 pr-3">Lượt trả lời</th>
                <th className="py-3 pr-3">Accuracy</th>
                <th className="py-3 pr-3">Câu sai</th>
              </tr>
            </thead>
            <tbody>
              {chapters.map((item) => (
                <tr key={item.chapter} className="border-b border-slate-100 dark:border-slate-800">
                  <td className="py-3 pr-3 font-medium text-slate-950 dark:text-white">
                    {item.chapter} · {item.chapterTitle}
                  </td>
                  <td className="py-3 pr-3 text-slate-700 dark:text-slate-200">
                    {item.attemptedQuestions}/{item.total}
                  </td>
                  <td className="py-3 pr-3 text-slate-700 dark:text-slate-200">{item.attempts}</td>
                  <td className="py-3 pr-3 text-slate-700 dark:text-slate-200">{item.accuracy}%</td>
                  <td className="py-3 pr-3 text-rose-700 dark:text-rose-300">{item.wrongQuestions}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
