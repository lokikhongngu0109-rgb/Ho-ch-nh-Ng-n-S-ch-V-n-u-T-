"use client";

import { ArrowRight, Flag, ListChecks, Play, RotateCcw, SkipForward, X } from "lucide-react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ChapterFilter } from "@/components/ChapterFilter";
import { EmptyState } from "@/components/EmptyState";
import { QuestionCard } from "@/components/QuestionCard";
import { QuizResult } from "@/components/QuizResult";
import { questions } from "@/data/questions";
import { filterQuestions } from "@/lib/filters";
import { sectionLabels } from "@/lib/labels";
import { buildStudyQueue, parseNumberParam } from "@/lib/quiz";
import { scoreAnswers } from "@/lib/scoring";
import { useProgress } from "@/lib/use-progress";
import type { ChoiceKey, Question, QuestionSection, StudyConfig } from "@/types/quiz";

export function PracticeClient() {
  const searchParams = useSearchParams();
  const { progress, ready, recordAnswer, markQuestion } = useProgress();
  const [chapter, setChapter] = useState(searchParams.get("chapter") ?? "all");
  const [section, setSection] = useState<QuestionSection | "all">(
    (searchParams.get("section") as QuestionSection | null) ?? "all",
  );
  const [amount, setAmount] = useState(parseNumberParam(searchParams.get("amount"), 20, questions.length));
  const [shuffleQuestions, setShuffleQuestions] = useState(searchParams.get("shuffle") !== "0");
  const [shuffleAnswers, setShuffleAnswers] = useState(searchParams.get("shuffleAnswers") === "1");
  const [onlyUnseen, setOnlyUnseen] = useState(searchParams.get("onlyUnseen") === "1");
  const [onlyWrong, setOnlyWrong] = useState(searchParams.get("onlyWrong") === "1");
  const [session, setSession] = useState<Question[] | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selected, setSelected] = useState<Record<string, ChoiceKey | undefined>>({});
  const [completed, setCompleted] = useState(false);
  const autoStarted = useRef(false);

  const config: StudyConfig = useMemo(
    () => ({
      chapter,
      section,
      amount,
      shuffleQuestions,
      shuffleAnswers,
      onlyUnseen,
      onlyWrong,
    }),
    [amount, chapter, onlyUnseen, onlyWrong, section, shuffleAnswers, shuffleQuestions],
  );

  const availableCount = filterQuestions(questions, config, progress).length;

  const startSession = useCallback(() => {
    const queue = buildStudyQueue(questions, config, progress);
    setSession(queue);
    setCurrentIndex(0);
    setSelected({});
    setCompleted(false);
  }, [config, progress]);

  useEffect(() => {
    const hasQuickStart =
      searchParams.has("mode") ||
      searchParams.has("section") ||
      searchParams.has("chapter") ||
      searchParams.has("onlyWrong");
    if (ready && hasQuickStart && !autoStarted.current) {
      autoStarted.current = true;
      startSession();
    }
  }, [ready, searchParams, startSession]);

  if (completed && session) {
    const result = scoreAnswers(session, selected);
    return (
      <div className="grid gap-5">
        <QuizResult
          total={result.total}
          correct={result.correct}
          percent={result.percent}
          items={result.items}
        />
        <button
          type="button"
          onClick={() => {
            setSession(null);
            setCompleted(false);
          }}
          className="inline-flex h-11 w-fit items-center justify-center gap-2 rounded-md border border-slate-300 bg-white px-4 text-sm font-semibold text-slate-800 shadow-sm transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
        >
          <RotateCcw aria-hidden size={16} />
          Chọn phiên mới
        </button>
      </div>
    );
  }

  if (!session) {
    return (
      <div className="grid gap-6">
        <section className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-col gap-2">
            <p className="text-sm font-semibold uppercase tracking-[0.16em] text-teal-700 dark:text-teal-300">
              Chọn chế độ học
            </p>
            <h2 className="text-2xl font-semibold text-slate-950 dark:text-white">Tùy chỉnh phiên luyện tập</h2>
            <p className="max-w-3xl text-sm leading-6 text-slate-600 dark:text-slate-300">
              Lọc câu hỏi theo chương, nhóm câu, trạng thái đã làm và lỗi sai. Kết quả lưu local-first trong trình
              duyệt.
            </p>
          </div>

          <div className="mt-5 grid gap-4 lg:grid-cols-3">
            <ChapterFilter questions={questions} value={chapter} onChange={setChapter} />
            <label className="grid gap-2 text-sm font-medium text-slate-700 dark:text-slate-200">
              Nhóm câu hỏi
              <select
                value={section}
                onChange={(event) => setSection(event.target.value as QuestionSection | "all")}
                className="h-11 rounded-md border border-slate-300 bg-white px-3 text-sm text-slate-950 shadow-sm outline-none transition focus:border-teal-600 focus:ring-2 focus:ring-teal-600/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                <option value="all">Tất cả nhóm</option>
                {Object.entries(sectionLabels).map(([key, label]) => (
                  <option key={key} value={key}>
                    {label}
                  </option>
                ))}
              </select>
            </label>
            <label className="grid gap-2 text-sm font-medium text-slate-700 dark:text-slate-200">
              Số lượng câu
              <input
                type="number"
                min={1}
                max={questions.length}
                value={amount}
                onChange={(event) => setAmount(Number(event.target.value))}
                className="h-11 rounded-md border border-slate-300 bg-white px-3 text-sm text-slate-950 shadow-sm outline-none transition focus:border-teal-600 focus:ring-2 focus:ring-teal-600/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </label>
          </div>

          <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Toggle label="Trộn câu hỏi" checked={shuffleQuestions} onChange={setShuffleQuestions} />
            <Toggle label="Trộn đáp án" checked={shuffleAnswers} onChange={setShuffleAnswers} />
            <Toggle label="Chỉ câu chưa làm" checked={onlyUnseen} onChange={setOnlyUnseen} />
            <Toggle label="Chỉ câu sai" checked={onlyWrong} onChange={setOnlyWrong} />
          </div>

          <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm text-slate-600 dark:text-slate-300">
              {ready ? `${availableCount} câu phù hợp bộ lọc` : "Đang tải tiến độ..."}
            </p>
            <button
              type="button"
              onClick={startSession}
              disabled={!ready}
              className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-teal-600 px-4 text-sm font-semibold text-white transition hover:bg-teal-700 disabled:cursor-not-allowed disabled:bg-slate-400"
            >
              <Play aria-hidden size={16} />
              Bắt đầu luyện tập
            </button>
          </div>
        </section>
      </div>
    );
  }

  if (!session.length) {
    return (
      <EmptyState
        icon={ListChecks}
        title="Không có câu phù hợp"
        description="Bộ lọc hiện tại không tìm thấy câu hỏi nào. Hãy đổi chương, nhóm câu hoặc tắt điều kiện chỉ câu sai/chưa làm."
        action={
          <button
            type="button"
            onClick={() => setSession(null)}
            className="inline-flex h-11 items-center justify-center rounded-md bg-teal-600 px-4 text-sm font-semibold text-white"
          >
            Sửa bộ lọc
          </button>
        }
      />
    );
  }

  const current = session[currentIndex];
  const currentSelected = selected[current.id];
  const record = progress.questions[current.id];
  const answered = Boolean(currentSelected);

  function nextQuestion() {
    if (currentIndex >= session!.length - 1) {
      setCompleted(true);
    } else {
      setCurrentIndex((index) => index + 1);
    }
  }

  function chooseAnswer(answer: ChoiceKey) {
    if (selected[current.id]) {
      return;
    }
    setSelected((value) => ({ ...value, [current.id]: answer }));
    recordAnswer(current, answer, "practice");
  }

  return (
    <div className="grid gap-5">
      <section className="flex flex-col gap-3 rounded-lg border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-sm font-medium text-slate-600 dark:text-slate-300">
            Câu {currentIndex + 1}/{session.length}
          </p>
          <div className="mt-2 h-2 w-full min-w-64 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
            <div
              className="h-full rounded-full bg-teal-600"
              style={{ width: `${((currentIndex + 1) / session.length) * 100}%` }}
            />
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => markQuestion(current.id)}
            className="inline-flex h-10 items-center justify-center gap-2 rounded-md border border-amber-300 bg-amber-50 px-3 text-sm font-semibold text-amber-900 transition hover:bg-amber-100 dark:border-amber-700 dark:bg-amber-950/40 dark:text-amber-100"
          >
            <Flag aria-hidden size={16} />
            {record?.marked ? "Bỏ đánh dấu" : "Đánh dấu cần ôn"}
          </button>
          <button
            type="button"
            onClick={nextQuestion}
            className="inline-flex h-10 items-center justify-center gap-2 rounded-md border border-slate-300 bg-white px-3 text-sm font-semibold text-slate-800 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
          >
            <SkipForward aria-hidden size={16} />
            Bỏ qua
          </button>
          <button
            type="button"
            onClick={() => setCompleted(true)}
            className="inline-flex h-10 items-center justify-center gap-2 rounded-md border border-rose-200 bg-rose-50 px-3 text-sm font-semibold text-rose-800 transition hover:bg-rose-100 dark:border-rose-800 dark:bg-rose-950/40 dark:text-rose-100"
          >
            <X aria-hidden size={16} />
            Kết thúc
          </button>
        </div>
      </section>

      <QuestionCard
        question={current}
        selectedAnswer={currentSelected}
        reveal={answered}
        shuffleAnswers={shuffleAnswers}
        marked={record?.marked}
        onSelect={chooseAnswer}
      />

      <div className="flex justify-end">
        <button
          type="button"
          onClick={nextQuestion}
          className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-teal-600 px-4 text-sm font-semibold text-white transition hover:bg-teal-700"
        >
          {currentIndex >= session.length - 1 ? "Xem kết quả" : "Câu tiếp theo"}
          <ArrowRight aria-hidden size={16} />
        </button>
      </div>

      <Link href="/questions" className="text-sm font-medium text-teal-700 hover:underline dark:text-teal-300">
        Mở ngân hàng câu hỏi
      </Link>
    </div>
  );
}

function Toggle({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <label className="flex cursor-pointer items-center justify-between gap-3 rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm font-medium text-slate-800 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-100">
      {label}
      <input
        type="checkbox"
        checked={checked}
        onChange={(event) => onChange(event.target.checked)}
        className="h-5 w-5 accent-teal-600"
      />
    </label>
  );
}
