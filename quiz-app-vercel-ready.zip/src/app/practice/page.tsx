import { Suspense } from "react";
import { PracticeClient } from "@/app/practice/practice-client";

export default function PracticePage() {
  return (
    <Suspense fallback={<div className="rounded-lg border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">Đang tải...</div>}>
      <PracticeClient />
    </Suspense>
  );
}
